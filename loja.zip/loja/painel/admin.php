<?php 
require_once('../includes/nav_admin.php');
require_once('../includes/conexao.php');

$sql2 = "SELECT * FROM usuarios";
$busca2 = mysqli_query($conexao, $sql2);
$total2 = mysqli_num_rows($busca2);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Painel do Administrador</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Administração</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="text-danger">Usuários | Total de usuários: <?php echo $total2 ?></h4>
                            <br>
                            <table id="example2" class="table table-striped mb-0 table-responsive-sm">
                                <thead>
                                            <tr>
                                                <th>ID:</th>
                                                <th>Usuário:</th>
                                                <th>Cargo:</th>
                                                <th>Saldo:</th>
                                                <th>Compras:</th>
                                                <th>Ação:</th>

                                            </tr>
                                </thead>
                                <tbody>
<?php
 while($dados2 = mysqli_fetch_assoc($busca2)){?>
<tr id='user_<?php echo $dados2["id"]; ?>'>
    <td><?php echo strtoupper($dados2['id']);?></td>
    <td><?php echo strtoupper($dados2['usuario']);?></td>    
    <td><?php if($dados2['nivel'] == 1){ echo "Administrador";} else{ echo "Usuário";} ?></td>
    <td><?php echo strtoupper($dados2['saldo']);?></td>
    <td><?php echo strtoupper($dados2['lives']);?></td>
    <td><?php echo '<button class="btn btn-danger btn-sm" onclick=\'excluir('.($dados2["id"]).')\'>Excluir</button>'; ?></td>
</tr>
<?php } ?>
                               </tbody>
                            </table>
                        </div>
                    </div>
 
<!--- FUNCOES DISPONIVEIS --->
<div class="row">
                <div class="col-md-12 lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="text-danger">Funções Disponíveis:</h4>
                            <br>
                             <button class="btn btn-dark" type="button" data-toggle="modal" data-target="#Addsaldo"><i class="nav-link-icon" data-feather="dollar-sign"></i> Adicionar Saldo </button>
                          <button class="btn btn-dark" data-toggle="modal" data-target="#Addusuario"><i class="nav-link-icon" data-feather="user"></i> Adicionar Usuário</button>
                          <button class="btn btn-dark" data-toggle="modal" data-target="#Addnotificao"><i class="nav-link-icon" data-feather="send"></i> Adicionar Notificação</button>
                        <button class="btn btn-dark" type="button" data-toggle="modal" data-target="#Gerargift"><i class="nav-link-icon" data-feather="gift"></i> Gerar Gift </button>
                        </div>
                    </div>
                    
                    <!--- FIM FUNCOES DISPONIVEIS --->
 

<!--- INICIO MODAL --->

<div class="modal fade" id="Addusuario" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Adicionando um novo usuário!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="ti-close"></i>
        </button>
      </div>
        <form action="">
      <div class="modal-body">
       <div class="form-group">
        <input type="text" name="usuario" class="form-control" placeholder="Digite o nome do usuário:">
      </div>
      <div class="form-group">
        <input type="text" name="senha" class="form-control" placeholder="Digite uma senha:">
      </div>
      <div class="form-group">
        <input type="number" name="saldo" class="form-control" placeholder="Digite o saldo:">
      </div>
      <div name="nivel" class="form-group">
        <select class="form-control">
        <option value="0">Usuário</option>
        <option value="2">Vendedor</option>
        <option value="1">Administrador</option>
        </select>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar
        </button>
        <button type="submit" class="btn btn-success addusuario">Confirmar</button>
      </div>
    </div>
</form>
  </div>
</div>

<!--- FIM MODAL --->



<!--- INICIO MODAL --->
<div class="modal fade" id="Addsaldo" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Adicionando saldo ao usuário!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="ti-close"></i>
        </button>
      </div>
      <div class="modal-body">
       <div class="form-group">
        <input type="text" id="usuario2" class="form-control" placeholder="Digite o usuário:">
      </div>
      <div class="form-group">
        <input type="number" id="saldo2" class="form-control" placeholder="Digite o saldo:">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar
        </button>
        <button type="submit" id="btn_adicionar_saldo" class="btn btn-success">Confirmar</button>
      </div>
    </div>

  </div>
</div>

<!--- FIM MODAL --->


<!--- INICIO MODAL --->

<div class="modal fade" id="Addnotificao" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Enviando alertas!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="ti-close"></i>
        </button>
      </div>
      <div class="modal-body">
       <div class="form-group">
        <input type="text" id="msg" class="form-control" style="text-align: center;" placeholder="Informe a mensagem que deve ser enviada aos usuários:">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar
        </button>
        <button type="submit" id="notificar" class="btn btn-success">Confirmar</button>
      </div>
    </div>

  </div>
</div>

<!--- FIM MODAL --->


<!--- INICIO MODAL --->

<div class="modal fade" id="Gerargift" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Gerando códigos de saldo...</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="ti-close"></i>
        </button>
      </div>
      <div class="modal-body">
      <div class="form-group">
        <input type="number" id="valorgift" name="valorgift" class="form-control" placeholder="Digite o valor:">
      </div>
      <div class="form-group">
        <input type="number" id="meuid" name="meuid" class="form-control" placeholder="Digite o seu ID do Telegram:">
      </div>
       <div class="form-group">
        <input type="text" id="criador" name="criador" class="form-control" placeholder="Digite o seu usuário:" value="Pladix" disabled="">
      </div>
     <div class="form-group">
        <input type="text" id="statusgift" name="statusgift" class="form-control" placeholder="Digite a sua ação:" value="Ativado" disabled="">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar
        </button>
        <button type="submit" id="gerargift" class="btn btn-success">Confirmar</button>
      </div>
    </div>

  </div>
</div>

<!--- FIM MODAL --->

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
             <center>© Copyright 2021 - 2022 PladixStore v2 Developed by ❤️ PladixOficial</a></center>
        </div>
<!-- end::main -->
    </footer>
</main>

<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

$("#gerargift").click(function(){
   $(this).text("Gerando...");
   $(this).attr("disabled", true);

var valorgift = document.getElementById("valorgift").value;
var id_telegram = document.getElementById("meuid").value;
var criador = document.getElementById("criador").value;
var status = document.getElementById("statusgift").value;

 $.ajax({
  url: "modulos/apiConvite.php",
  type: "POST",
  data: {
    "valorgift": valorgift,
    "id_telegram": id_telegram,
    "criador": criador,
    "status": status,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#gerargift").text("Confirmar");
    $("#gerargift").attr("disabled", false);

  if(retorno.success == true){
    toastr.success("O código foi enviado para seu ID do Telegram."); 
    
  }else{
    toastr.error("Informações inválidas, tente novamente."); 
          }
      
        }
      }); //ajax
   });

</script>

<script type="text/javascript">
$("#btn_adicionar_saldo").click(function(){
   $(this).text("Aguarde...");
   $(this).attr("disabled", true);

var usuario2 = document.getElementById("usuario2").value;
var saldo2 = document.getElementById("saldo2").value;

 $.ajax({
  url: "modulos/apiadicionarSaldo.php",
  type: "POST",
  data: {
    "usuario2": usuario2,
    "saldo2": saldo2,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_adicionar_saldo").text("Adicionado...");
    $("#btn_adicionar_saldo").attr("disabled", false);

  if(retorno.success == true){
    toastr.success("O saldo foi adicionado com sucesso!"); 
    
  }else{
    toastr.error("Não foi possivel adicionar este saldo!"); 
          }
      
        }
      }); //ajax
   });

</script>



<script type="text/javascript">

$("#notificar").click(function(){
   $(this).text("Aguarde...");
   $(this).attr("disabled", true);

var msg = document.getElementById("msg").value;

 $.ajax({
  url: "modulos/addNotify.php",
  type: "POST",
  data: {
    "msg": msg,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#notificar").text("Enviada...");
    $("#notificar").attr("disabled", false);

  if(retorno.success == true){
    toastr.success("O alerta foi enviado com sucesso!"); 
    
  }else{
    toastr.error("Falha ao enviar alerta."); 
          }
      
        }
      }); //ajax
   });

</script>


<script type="text/javascript">
var total_usuarios = <?php echo($total2); ?>;

$(document).ready(function(){

var timer = setInterval(function(){
 
$.ajax({
url: "apiBlock.php",
dataType: 'json',
success: function(retorno){
if(retorno.success === false){
  clearInterval(timer);
  Swal.fire({ title: "Opss!", text: "Um novo dispositivo foi detectado, tente novamente mais tarde.", icon: "error", confirmButtonText: "OK", confirmButtonClass: 'btn btn-primary', buttonsStyling: false, allowOutsideClick: false, allowEscapeKey: false}).then(function(status){
    if(status.isConfirmed === true){
       location.href = "../?logout=true";      
            }
          });
        }
      }
    });
  }, 3000);
});

</script>

<script type="text/javascript">
$('form').submit(function(submit){
$('.addusuario').text('Aguarde...');
$('.addusuario').attr("disabled", true);

  submit.preventDefault();

    var data = $('form').serialize();
    $.ajax({
        url: 'modulos/apiCadastrar.php',
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(resultado){
            
            $('.addusuario').text('Adicionado...');
            $('.addusuario').attr("disabled", false);
            
            if(resultado.success == true){
            toastr.success("Usuário adicionado com sucesso."); 
                }
                else{
            toastr.error(resultado['message']); 
              }
            }
    });
});

function excluir(id){
  $.ajax({
      url: 'modulos/deletar.php',
      type: 'POST',
      data: {"id": id},
      dataType: 'json',
      success: function(resultado){
        if(resultado.success){
          $('#user_' + id).remove();
          total_usuarios = total_usuarios -1;
          $('#total_usuarios').text(total_usuarios);
          toastr.success('O usuário foi excluido com sucesso!');          
          }else{
           toastr.error('Não foi possivel excluir este usuário.'); 
          }           
      }
  });
}

</script>
<script src="vendors/bundle.js"></script>

<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<script src="vendors/prism/prism.js"></script>
<script src="assets/js/app.min.js"></script>

<!-- Plugin scripts -->
<!-- DataTable -->
</body>
</html>