<?php 
header("Location: ./");
require_once('../includes/nav_menu.php');
require_once('../includes/conexao.php');

$usuario = $_SESSION['usuario'];

$sql0 = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$buscausersql = mysqli_query($conexao, $sql0);
$sqldados = mysqli_fetch_assoc($buscausersql);

$sql = "SELECT * FROM usuarios";
$busca = mysqli_query($conexao, $sql);
$totalusuarios = mysqli_num_rows($busca);

$sql1 = "SELECT * FROM notify";
$buscas1 = mysqli_query($conexao, $sql1);
$totalnotify = mysqli_num_rows($buscas1);

$sql2 = "SELECT * FROM cards";
$buscas2 = mysqli_query($conexao, $sql2);
$carddisponivel = mysqli_num_rows($buscas2);

$sql3 = "SELECT * FROM cardsvendidos WHERE usuario = '$usuario'";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos = mysqli_num_rows($buscas3);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Comprar Consultáveis</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Comprar Consultáveis</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">

                  <div class="row">
                        <div class="col-md-4">
                            <div class="card card-body">
                                <h3 class="mb-3">
                           <?php echo $carddisponivel ?>
                                    <small>Consultáveis Disponíveis:</small>
                                </h3>
                                <div class="progress mb-2" style="height: 5px">
                                    <div class="progress-bar bg-success" role="progressbar"
                                         style="width: 100%;"
                                         aria-valuenow="50" aria-valuemin="0" aria-valuemax="56"></div>
                                </div>
                                <p class="font-size-11 m-b-0">
                                 Quantidade total de Consultaveis disponiveis
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-body">
                                <h3 class="mb-3">
                            <?php echo $cardsvendidos ?>
                                    <small>Compras</small>
                                </h3>
                                <div class="progress mb-2" style="height: 5px">
                                    <div class="progress-bar bg-warning" role="progressbar"
                                         style="width: 100%;"
                                         aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="font-size-11 m-b-0">
                                Seu total de compras no site
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-body">
                                <h4 class="mb-3">
                                    R$<?php echo $_SESSION['saldo'] ?>
                                    <small>Saldo</small>
                                </h4>
                                <div class="progress mb-2" style="height: 5px">
                                    <div class="progress-bar bg-info" role="progressbar"
                                         style="width: 100%;"
                                         aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="font-size-11 m-b-0">
                                Quantidade de saldo
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <table id="example2" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>BIN</th>
                                    <th>Sexo</th>
                                    <th>Limite disponivel</th>
                                    <th>Nome</th>
                                    <th>Comprar</th>
                                </tr>
                                </thead>
                                <tbody>
                        <?php
                            while($dados2 = mysqli_fetch_assoc($buscas2)){?>
                             <tr id='<?php echo $dados2["card_token"]; ?>'>
                                    <td class="text-danger"><?php echo strtoupper($dados2['bin']);?></td>
                                    <td>R$<?php echo strtoupper($dados2['valorcc']);?>,00</td>
                                    <td><?php echo strtoupper($dados2['vendendor']);?></td>
                                    <td><?php if($dados2['cpf'] == 1){ echo "<span class='text-danger'>Não</span>"; } else{ echo "<span class='text-success'>Sim</span>"; } ?></td>
                                    <td><?php echo strtoupper($dados2['bandeira']);?></td>
                                    <td><?php echo strtoupper($dados2['banco']);?></td>
                                    <td><?php echo strtoupper($dados2['nivel']);?></td>
                                    <td><?php echo strtoupper($dados2['pais']);?></td>
                                        <td><button id="btn_comprar" class="btn btn-success" onclick="compra(`<?php echo $dados2['card_token']; ?>`)">Comprar</button></td> 
                                </tr>
                        <?php } ?>
                            </table>
                        </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
           <center>© Copyright 2021 - 2022 PladixStore v2 Developed by ❤️ PladixOficial</a></center>
        </div>
<!-- end::main -->
    </footer>
</main>


<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

function compra(card_token){
$(this).text("Comprando...");
$(this).attr("disabled", true);

 $.ajax({
  url: "modulos/apiCompra.php",
  type: "POST",
  data: {
    "card_token": card_token, 
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_comprar").text("Comprar");
    $("#btn_comprar").attr("disabled", false);

  if(retorno.success == true){
   toastr.success(retorno['message']);
  setTimeout(function(){
  window.location.href = "mypurchases.php";
    }, 3000);
  }else{
    toastr.error(retorno['message']);
          }
        }
   }); //ajax
}

</script>

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<script type="text/javascript">
toastr.success("Boas compras :)")
</script>
<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>

</body>
</html>