<?php 
require_once('../includes/nav_menu.php');
require_once('../includes/conexao.php');

$usuario = $_SESSION['usuario'];

$sql0 = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$buscausersql = mysqli_query($conexao, $sql0);
$sqldados = mysqli_fetch_assoc($buscausersql);

$sql = "SELECT * FROM usuarios";
$busca = mysqli_query($conexao, $sql);
$totalusuarios = mysqli_num_rows($busca);

$sql1 = "SELECT * FROM notify";
$buscas1 = mysqli_query($conexao, $sql1);
$totalnotify = mysqli_num_rows($buscas1);

$sql2 = "SELECT * FROM cards";
$buscas2 = mysqli_query($conexao, $sql2);
$carddisponivel = mysqli_num_rows($buscas2);

$sql3 = "SELECT * FROM cardsvendidos WHERE usuario = '$usuario'";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos = mysqli_num_rows($buscas3);

$sql3 = "SELECT * FROM cardsvendidos";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos2 = mysqli_num_rows($buscas3);

$sql3 = "SELECT * FROM cardsvendidos WHERE usuario = '$usuario'";
$buscas3 = mysqli_query($conexao, $sql3);
$dados2 = mysqli_num_rows($buscas3);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Suas Compras</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Suas Compras</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="col-xl-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">Suas Compras | Total de compras: <font color='red'><?php echo $cardsvendidos ?></font></h4>
</div>
<div class="card-header justify-content-center">
<b>
<div class="col-sm-8">
<ul>
<b>
<li>
<font color='orange'><i class="mdi mdi-checkbox-blank-circle"></i></font>
Você tem <code>5 minutos</code> pra reembolsar a CC, lembrando que você so pode ultilizar a opção de reembolso 1 vez.
</li>
<br>
</b>
</ul>
</div>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table table-striped">
<thead>
<tr>
<th>Cartão</th>
<th>Nome</th>
<th>CPF</th>
<th>Bin</th>
<th>Valor</th>
<th>Data da compra</th>
<th>Reembolso</th>
</tr>
</thead>
<tbody>
 <?php
 while($dados2 = mysqli_fetch_assoc($buscas3)){?>
<tr id='<?php echo $dados2["card_token"]; ?>'>
                                    <td class="text-danger"><?php echo strtoupper($dados2['card']);?>|<?php echo strtoupper($dados2['mes']);?>|<?php echo strtoupper($dados2['ano']);?>|<?php echo strtoupper($dados2['cvv']);?></td>
                                    <td><?php echo $dados2['nome'];?></td>
                                    <td><?php echo $dados2['cpf'];?></td>
                                    <td><?php echo $dados2['bandeira'];?> <?php echo $dados2['banco'];?> <?php echo $dados2['nivel'];?></td>
                                    <td>R$<?php echo $dados2['valorcc'];?>,00</td>
                                    <td><?php echo $dados2['data_c'];?></td>
                                    <td><button id="btn_Reembolsar" class="btn btn-success" onclick="compra('<?php echo $dados2["card_token"]; ?>')">Reembolsar</button></td>
                               </tr>
<?php } ?>
                               </tbody>
                            </table>
                        </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
           <center>© Copyright 2021 - 2022 PladixStore v2 Developed by ❤️ PladixOficial</a></center>
        </div>
<!-- end::main -->
    </footer>
</main>

<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

function compra(card_token){
$(this).text("Processando...");
$(this).attr("disabled", true);

 $.ajax({
  url: "modulos/apiReembolso.php",
  type: "POST",
  data: {
    "card_token": card_token,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_Reembolsar").text("Reembolsar");
    $("#btn_Reembolsar").attr("disabled", false);

  if(retorno.success == true){
      toastr.success(retorno['message']);
  }else{
    toastr.error(retorno['message']);
          }
        }
   }); //ajax
}

</script>
<script src="vendors/bundle.js"></script>

<script type="text/javascript">
swal("Aviso", "O checker está ativo para você solicitar reembolso, lembre-se de usar apenas essa função caso tenha certeza que o cartão não está live, pois usar vai fazer você perder seu saldo pago nestes cartões. E lembramos que você tem apenas 10 minutos para reembolsar as suas compras.", "warning");
</script>

<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<script src="vendors/prism/prism.js"></script>
<script src="assets/js/app.min.js"></script>

<!-- Plugin scripts -->
<!-- DataTable -->
</body>
</html>