<?php include("../includes/nav_menu.php"); ?>

    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Adicionar Saldo</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Adicionar Saldo</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">
       
                           <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Escolha uma forma de pagamento:</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <select required="" id="formadepagamento" class="form-control form-control-lg">
                                            <option>Selecione a forma de pagamento:</option>
                                            <option disabled="" value="pixmanual">Pagamento via Pix (Manual)</option>
                                            <option disabled="" value="gerencianet">GerenciaNet (Pix Instantâneo)</option>
                                            <option value="mercadopago">MercadoPago (Pix Instantâneo)</option>
                                            <option disabled="" value="pagseguro">PagSeguro (Pix Instantâneo)</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div data-label="Adicionar Saldo" class="demo-code-preview">
                                <pre><code class="language-html">Informe um valor para depósito.</code>
                                      <form class="form-inline">
                                        <div class="form-group mx-sm-3 mb-2">
                                            <label for="inputPassword6" class="sr-only">Informe o valor:</label>
                                            <input type="number" id="valor" class="form-control" placeholder="Informe o valor:">
                                        </div>
                                        <button type="submit" class="btn btn-success mb-2 confirmar">Confirmar valor</button>
                                    </form>
                                </pre>
                            </div>
                        </div>
                    </div>
       

                        </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
       <footer>
        <div class="container">
              <center>© Copyright 2024 - 2025 Venompcx v2 Developed by ❤️ </a></center>
        </div>
<!-- end::main -->
    </footer>
</main>

<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

$(document).ready(function(){
var timer = setInterval(function(){

$.ajax({
url: "apiBlock.php",
dataType: 'json',
success: function(retorno){
if(retorno.success === false){
    clearInterval(timer);
    Swal.fire({ title: "Opss!", text: "Detectamos um novo dispositivo conectado!", icon: "error", confirmButtonText: "OK", confirmButtonClass: 'btn btn-primary', buttonsStyling: false, allowOutsideClick: false, allowEscapeKey: false}).then(function(status){
        if(status.isConfirmed === true){
           location.href = "../?logout=true";          
            }
          });
        }
      }
    });
  }, 3000);
});

$('form').submit(function(submit){
$('.confirmar').text('Processando...');
$('.confirmar').attr("disabled", true);

submit.preventDefault();

var valor = $('#valor').val().trim();
var formadepagamento = $('#formadepagamento').val().trim();

grecaptcha.ready(function(){
grecaptcha.execute("6LdGZo8eAAAAAA3NeqRHK58-7Kmy9rSQkIM3iQ9n", {action: 'homepage'}).then(function(response){

  $.ajax({
    url: 'modulos/apiDeposito.php',
    type: 'POST',
    data: {
      "action_type": formadepagamento,
      "valor": valor,
      "g-recaptcha-response": response
      },
    dataType: 'json',
    success: function(resultado){

      $('.confirmar').text('Prosseguir');
      $('.confirmar').attr("disabled", false);

if(resultado.success == true){  
const {action_type} = resultado

const ActionTypes = {
mercadopago(){
swal("Success", "Finalize o pagamento no MercadoPago que você será redirecionado.", "success");

    const {init_point} = resultado

    setTimeout(() => {
        location.href = init_point
    }, 3000)
 },

pixmanual(){
swal("Success", "Pague para o Pix E-mail: (sem informacao) para receber seu saldo imediatamente, lembre-se de pagar com a observação do seu usuário.", "success");
    }


}


const executeAction = ActionTypes[action_type]

executeAction()

} else {

swal("Error", resultado['message'], "error");
}
      }
      });
    });
  });
});


</script>
<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>
</body>
</html>