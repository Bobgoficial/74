<?php

session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

date_default_timezone_set('America/Sao_Paulo');

require_once("../../includes/conexao.php");
$token = md5(uniqid());

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
$saldo = mysqli_real_escape_string($conexao, $_POST['saldo']);
$nivel = mysqli_real_escape_string($conexao, $_POST['nivel']);

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$result = mysqli_query($conexao, $sql);

if(mysqli_num_rows($result) >= 1) {
$json = array("success" => false, "message" => "Opss!, este usuário já existe.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}

if($saldo > 0  && ctype_digit($saldo)){

$cad = mysqli_query($conexao, "INSERT INTO usuarios (usuario, senha, saldo, chave, nivel)
VALUES ('$usuario', md5('$senha'), '$saldo', '$token', '$nivel');");

if(mysqli_affected_rows($conexao) > 0) {
$json = array("success" => true, "message" => "Parabéns, o cadastro foi criado com sucesso.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}}else{
$json = array("success" => false, "message" => "O saldo informado é inválido.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>