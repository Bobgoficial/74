<?php

session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../../");
exit();
}

require_once("../../includes/conexao.php");

$busca = mysqli_query($conexao, "DELETE from cards");

if(mysqli_affected_rows($conexao) > 0){
	$json = array("success" => true, "message" => "Todos os cards deletados!");
echo json_encode($json);
exit();
}else{
	$json = array("success" => false, "message" => "Não deletado!");
echo json_encode($json);
exit();
}


?>