<?php
error_reporting(0);
date_default_timezone_set('America/Sao_Paulo');
session_start();
require_once("../../includes/conexao.php");

$codigo = $_POST['codigo'];

if(empty($codigo)){
$json = array("success" => false, "message" => "Código inválido, tente novamente.");
echo json_encode($json);
exit();
}

function x($num){
  $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $total = strlen($chars);
  $str = "";
  while($num > 0){
    $str .= $chars[rand(0, $total)];
    $num--;
  }
  return trim($str);
}
$convite = trim(x(4)."-".x(4)."-".x(4)."-".x(4));
$date = date("Y-m-d H:i:s");
$id = rand(1111,9999);
$sql = "INSERT INTO gift (id, gift, status, valor, usuario) VALUES ('$id', '$convite', '$status', '$valor', '$criador')";
$result = mysqli_query($conexao, $sql);

if(mysqli_affected_rows($conexao) > 0){
$json = array("success" => true, "message" => "O código foi criado com sucesso!");
echo json_encode($json);
mysqli_close($conexao);
exit();
}
  
else{
$json = array("success" => false, "message" => "Não foi possível criar este código.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>

