<?php

session_start();
if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

require_once("../../includes/conexao.php");

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario2']);
$saldo = mysqli_real_escape_string($conexao, $_POST['saldo2']);

if(empty($usuario) || empty($saldo)){
$json = ["success" => false, "message" => "Você não preencheu os campos."];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

if(!is_numeric($saldo) || $saldo < 1){
$json = ["success" => false, "message" => "O saldo informado é abaixo de 1, não será possível adicionar."];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$buscar = mysqli_query($conexao, "SELECT * FROM usuarios WHERE usuario = '$usuario'");

if(mysqli_num_rows($buscar) < 1){
$json = ["success" => false, "message" => "Usuário inexistente."];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$dados = mysqli_fetch_assoc($buscar);

$saldo_atual = trim($dados["saldo"]);
$chave = trim($dados["chave"]);
$novo_saldo = $saldo + $saldo_atual;

mysqli_query($conexao, "UPDATE usuarios SET saldo = '$novo_saldo' WHERE chave = '$chave'");

if(mysqli_affected_rows($conexao) > 0){
$txt = "⚙️ | *PladixStore - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informação da Loja Virtual:*
- Ação: *Novo saldo adicionado!*
- Usuário: *$usuario*
- Valor adicionado: *$novo_saldo*

- *Fique esperto aos nossos alertas, sempre serão enviados com segurança a vocês!*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => "-1001768892332", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));
$json = ["success" => true, "message" => "Parabéns! O saldo foi adicionado com sucesso."];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

?>