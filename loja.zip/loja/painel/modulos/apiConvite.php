<?php
error_reporting(0);
session_start();
require_once("../../includes/conexao.php");

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

$valor = $_POST['valorgift'];
$idtelegram = $_POST['id_telegram'];
$status = $_POST['status'];
$criador = $_POST['criador'];

if(empty($valor)){
$json = array("success" => false, "message" => "Não foi encontrado o valor inserido.");
echo json_encode($json);
exit();
}

if(empty($idtelegram)){
$json = array("success" => false, "message" => "Não foi encontrado o valor inserido.");
echo json_encode($json);
exit();
}

if(empty($status)){
$json = array("success" => false, "message" => "Não foi encontrado o valor inserido.");
echo json_encode($json);
exit();
}

if(empty($criador)){
$json = array("success" => false, "message" => "Não foi encontrado o valor inserido.");
echo json_encode($json);
exit();
}

date_default_timezone_set('America/Sao_Paulo');

function x($num){
  $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $total = strlen($chars);
  $str = "";
  while($num > 0){
    $str .= $chars[rand(0, $total)];
    $num--;
  }
  return trim($str);
}

$convite = trim(x(4)."-".x(4)."-".x(4)."-".x(4));

$date = date("Y-m-d H:i:s");
$id = rand(1111,9999);
$sql = "INSERT INTO gift (id, gift, status, valor, usuario) VALUES ('$id', '$convite', '$status', '$valor', '$criador')";
$result = mysqli_query($conexao, $sql);

if(mysqli_affected_rows($conexao) > 0){
$txt = "⚙️ | *PladixStore - Administração*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Código Presente (Gift):*
- Código: `$convite`
- Valor: *$valor*
- ID do Telegram: *$idtelegram*
- Status: *$status*
- Criador: *$criador*

ℹ️ | *Para resgatar este código entre no site abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => "$idtelegram", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));
$json = array("success" => true, "message" => "O código foi criado com sucesso!");
echo json_encode($json);
mysqli_close($conexao);
exit();
}
  
else{
$json = array("success" => false, "message" => "Não foi possível criar este código.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>

