<?php
session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

date_default_timezone_set('America/Sao_Paulo');

require_once("../../includes/conexao.php");
$token = md5(uniqid());

$msg = mysqli_real_escape_string($conexao, $_POST['msg']);
$id = $_SESSION['id'];
$usuario = $_SESSION['usuario'];
$data = date("d-m-Y H:i:s");

$sql = "INSERT INTO notify (id,msg,data,usuario) VALUES ('$id','$msg','$data','$usuario')";
$result = mysqli_query($conexao, $sql);

if(mysqli_affected_rows($conexao) > 0){
$txt = "⚙️ | *PladixStore - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informação da Loja Virtual:*
- Ação: *Uma nova notificação foi enviada com sucesso!*
- Mensagem: *$msg*
- Data do Envio: *$data*
- Enviada por: *@PladixOficial*

- *Fique esperto aos nossos alertas, sempre serão enviados com segurança a vocês!*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => "-1001768892332", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));
$json = array("success" => true, "message" => "O alerta foi enviado com sucesso!");
echo json_encode($json);
mysqli_close($conexao);
exit();
}

else{
$json = array("success" => false, "message" => "O alerta não foi enviado, tente novamente.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>