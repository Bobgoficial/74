<?php
error_reporting(0);
session_start();
date_default_timezone_set('America/Sao_Paulo');

require_once("../../includes/conexao.php");
if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

$usuario = $_SESSION['usuario'];


if(empty($_GET['ccs_list'])){
$json = ["success" => false, "message" => "Informacoes invalidas, cartao nao adicionado."];
die(json_encode($json));
}

$lista = str_replace(array(" "), '/', $_GET['ccs_list']);
$regex = str_replace(array(':',";","|",",","=>","-"," ",'/','|||'), "|", $lista);

if (!preg_match("/[0-9]{15,16}\|[0-9]{2}\|[0-9]{2,4}\|[0-9]{3,4}/", $regex,$lista)){
$json = ["success" => false, "message" => "Informacoes invalidas, cartao nao adicionado."];
die(json_encode($json));
}

$dados = $lista[0];
$ccs = explode("|", $dados)[0];
$month = explode("|", $dados)[1];
$year = explode("|", $dados)[2];
$cvv = explode("|", $dados)[3];
$bin = substr($ccs, 0, 6);

sleep(4);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://storebot.store/binsearch.php?bin=$bin");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_POST, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bin = curl_exec($ch);
$dados = json_decode($bin, true);
$bin = $dados["bin"];
$bandeira = $dados["bandeira"];
$tipo = $dados["tipo"];
$nivel = $dados["nivel"];
$banco = $dados["banco"];
$pais = $dados["pais"];
curl_close($ch);
/////////////////////////////////////
$pais = mb_strtoupper($pais);
$paiscode = mb_strtoupper($pais);
$banco = mb_strtoupper($banco);
$level = mb_strtoupper($nivel);
$bandeira = mb_strtoupper($bandeira);
//////////////////////////////////////
if($level == 'GOLD'){
$valorcc = "5";
}

if($level == 'PREPAID'){
$valorcc = "5";
}

if($level == 'PREPAID BUSINESS'){
$valorcc = "5";
}

if($level == 'STANDARD'){
$valorcc = "5";
}

if($level == 'CLASSIC'){
$valorcc = "5";
}

if($bandeira == 'HIPERCARD'){
$valorcc = "5";
}

if($level == 'WORLD'){
$valorcc = "5";
}

if($level == 'SIGNATURE'){
$valorcc = "5";
}

if($bandeira == 'ELO'){
$valorcc = "5";
}

if($level == 'PLATINUM'){
$valorcc = "5";
}

if($level == 'BUSINESS'){
$valorcc = "5";
}

if($level == 'BLACK'){
$valorcc = "5";
}

if($level == 'INFINITE'){
$valorcc = "5";
}

if($bandeira == 'AMERICAN EXPRESS'){
$valorcc = "5";
}


if($level == ''){
$valorcc = "5";
}

if($level == 'DISCOVER'){
$valorcc = "5";
}

if($level == 'CORPORATE T&E'){
$valorcc = "5";
}

if($banco == 'PAGSEGURO INTERNET LTDA'){
$valorcc = "5";
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);
$dados1 = json_decode($dados, 1);

$name = $dados1["nome"];
$cpf2 = $dados1["cpf"];



if($cpf2 == ""){
$cpf = "1";
}
else{
}



if ($name == ""){
$nome = "1";
}
else{
}

$card_token = md5(uniqid());

/*$txt = "⚙️ | *PladixStore - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informação da Loja Virtual:*
- Ação: *Estoque disponível, realize sua recarga e compre cc's conosco!*

- *Fique esperto aos nossos alertas, sempre serão enviados com segurança a vocês!*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => "-1001768892332", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));*/

if($ccs !== ""){
$sql = "INSERT INTO `cards` (`card`, `mes`, `ano`, `cvv`, `valorcc`, `nome`, `cpf`, `bin`, `pais`, `bandeira`, `nivel`, `banco`, `vendendor`, `card_token`) VALUES ('$ccs','$month','$year','$cvv','$valorcc','$name','$cpf2','$bin','$pais','$bandeira','$level','$banco','$usuario','$card_token')";
$resultado = mysqli_query($conexao, $sql);

$json = ["success" => true, "message" => "$bin - Cartão foi adicionado com sucesso!"];
die(json_encode($json));

}
elseif($ccs == ""){
$json = ["success" => false, "message" => "Informe o cartão corretamente, para ser adicionado."];
die(json_encode($json));
}

else{

$json = ["success" => false, "message" => "Ocorreu um erro na hora de adicionar este cartão."];
die(json_encode($json));

}
?>