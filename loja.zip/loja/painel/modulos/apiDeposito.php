<?php

session_start();
require_once("../../includes/manage.php");
require_once("../../includes/conexao.php");

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$valor = mysqli_real_escape_string($conexao, $_POST['valor']);
$chave = trim($_SESSION["chave"]);
$action = trim($_POST["action"]);
$action_type = trim($_POST["action_type"]);
$saldo = trim($_SESSION["saldo"]);

if (empty($valor)) {
    $json = [
        "success" => false,
        "message" => "Você não informou nenhum valor."
    ];
    echo json_encode($json);
    exit();
}


    if ($valor < 1 || !ctype_digit($valor)) {
        $json = [
            "success" => false,
            "message" => "Para continuar informe um valor igual ou superior a 1 para poder adicionar o seu saldo."
        ];
        echo json_encode($json);
        exit();
    }
    
        if ($valor > 500 || !ctype_digit($valor)) {
        $json = [
            "success" => false,
            "message" => "O máximo que pode ser adicionado é 500, você coloque valor igual ou menor para adicionar de saldo."
        ];
        echo json_encode($json);
        exit();
    }


if($action_type == "mercadopago"){

    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => "https://api.mercadopago.com/checkout/preferences?access_token=$access_token",
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_HTTPHEADER => array(
            'content-type:application/json'),
        CURLOPT_POSTFIELDS => '{"items":[{"title":"RecargaPix - '.$valor.'","currency_id":"BRL","quantity":1,"unit_price":'.$valor.'}],"back_urls":{"success":"'.$host.'/lojavirtual/pagamentos/","failure":"'.$host.'/lojavirtual/pagamentos/","pending":"'.$host.'/lojavirtual/pagamentos/"},"auto_return":"approved","payment_methods":{"excluded_payment_types":[{"id":"credit_card"}],"installments":1},"notification_url":"'.$host.'/lojavirtual/pagamentos/notificacao.php","external_reference":"'.$chave.'"}'));
    $request = curl_exec($ch);

    $dados = json_decode($request, true);

    if (isset($dados["init_point"])) {
        $json = [
            "success" => true,
            "message" => null,
            "action_type" => $action_type,
            "init_point" => $dados["init_point"]
        ];
        echo json_encode($json);
        exit();
    } else {
        $json = [
            "success" => false,
            "message" => "O MercadoPago encontrou uma falha na sua solicitação."
        ];
        echo json_encode($json);
        exit();
    }

}

elseif($action_type == "gerencianet"){
        $json = [
            "success" => false,
            "message" => "Não foi possível concluir sua solicitação.",
            "action_type" => $action_type,
        ];
        echo json_encode($json);
        exit();
    }

elseif($action_type == "pagseguro"){
    $json = [
            "success" => false,
            "message" => "Não foi definido uma conta PagSeguro para receber pagamentos.",
            "action_type" => $action_type,
        ];
        echo json_encode($json);
        exit();
}

elseif($action_type == "pixmanual"){
    $json = [
            "success" => true,
            "message" => "O pagamento via Pix Manual, é via E-mail: pix@pladix.live que você pagará o valor de depósito e entrará em contato pelo @PladixOficial no Telegram para receber seu saldo.",
            "action_type" => $action_type,
        ];
        echo json_encode($json);
        exit();
}

else{

}

?>