<?php

session_start();
require_once('../includes/conexao.php');

$chave = $_SESSION["chave"];
$auth_token = $_SESSION["auth_token"];

$busca = mysqli_query($conexao, "SELECT auth_token FROM usuarios WHERE chave = '$chave'");
$dados = mysqli_fetch_assoc($busca);

if($dados["auth_token"] === $auth_token){
$json = array("success" => true);
echo json_encode($json);
exit();
}else{
session_unset();
session_destroy();
$json = array("success" => false);
echo json_encode($json);
exit();
}

?>