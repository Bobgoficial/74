<?php 
require_once('../includes/conexao.php');
require_once('../includes/nav_admin.php');

$data = mysqli_query($conexao, "SELECT * FROM cards");
$total = mysqli_num_rows($data);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Gerenciar Estoque</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="#">Administração</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Gerenciar Estoque</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">

                   <div class="auth-form card">
<div class="card-header justify-content-center">
<h4 class="card-title">Adicionar CC's | Sem Checker</h4>
</div>
<div class="card-body">
<div id="content">
<label>Lista de Cartões:</label>
<textarea class="form-control" id="ccs_list" rows="3" placeholder="Coloque a lista de cartões aqui!"></textarea>
<div class="help-block">
</div>
</div>
<div class="text-center">
<br><br>
<button id="btn_enviarcards" type="button" class="btn btn-success btn-block">Adicionar Cartões</button>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content-body">
<div class="container">
<div class="row">
<div class="col-xl-12">
<div class="card">
<div class="card-header">
<h3 class="card-title">CC's cadastradas | Total de CC's cadastradas: <font color="red"><?php echo $total ?></font></h3>
</div>
<div class="card-body">
<div class="transaction-table">
<div class="table-responsive">
<table class="table linked_account">
<thead>
<tr>
<th>Cartão:</th>
<th>Bandeira:</th>
<th>Nivel:</th>
<th>Pais:</th>
<th>Info:</th>
<th>Valor:</th>
<th>Ação:</th>
</tr>
</thead>
<tbody>
<?php
 while($dados2 = mysqli_fetch_assoc($data)){?>
<tr id='card_<?php echo $dados2["id"]; ?>'>
    <td><?php echo strtoupper($dados2['bin']);?></td>
    <td><?php echo strtoupper($dados2['bandeira']);?></td>
    <td><?php echo strtoupper($dados2['nivel']);?></td>
    <td><?php echo strtoupper($dados2['pais']);?></td>
    <td><?php if($dados2['cpf'] == 1){ echo "Não"; } else{ echo "Sim"; } ?></td>
    <td>R$<?php echo strtoupper($dados2['valorcc']);?></td>
    <td><?php echo '<button class="btn btn-danger btn-sm" onclick=\'excluir('.($dados2["id"]).')\'>Excluir</button>'; ?></td>    
</tr>
<?php } ?>
                            </table>
                        </div>
                    </div>
                    
                    
                    <!---- fim da sessao ---->
                    
                    </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
          <center>© Copyright 2024 - 2025 Venompcx v1 Developed by ❤️ </a></center>
        </div>
<!-- end::main -->
    </footer>
</main>


<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
$("#add_nivel").click(function(){
   $(this).text("AGUARDE..");
   $(this).attr("disabled", true);

var nivel = document.getElementById("nivel").value;

 $.ajax({
  url: "modulos/addNivel.php",
  type: "POST",
  data: {
    "nivel": nivel,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#add_nivel").text("Add");
    $("#add_nivel").attr("disabled", false);

  if(retorno.success == true){
   toastr.success('Nivel adicionado com successo');
  }else{
     toastr.error($retorno['message']);
          }
      
        }
      }); //ajax
   });

</script>


<script type="text/javascript">
$("#deletartudo").click(function(){
   $(this).text("AGUARDE..");
   $(this).attr("disabled", true);


 $.ajax({
  url: "modulos/deletartudo.php",
  type: "POST",
  data: {
  },
  dataType: "json",
  success: function(retorno){
    
    $("#deletartudo").text("DELETAR TUDO");
    $("#deletartudo").attr("disabled", false);

  if(retorno.success == true){
   toastr.success('Todos os cartões do estoque foram excluídos.');
  }else{
   toastr.error($retorno['message']);
          }
      
        }
      }); //ajax
   });

</script>



<script type="text/javascript">
$(document).ready(function(){

var timer = setInterval(function(){
 
$.ajax({
url: "apiBlock.php",
dataType: 'json',
success: function(retorno){
if(retorno.success === false){
    clearInterval(timer);
     toastr.error('Novo login detectado (desconectando..)').then(function(status){
        if(status.isConfirmed === true){
           location.href = "../?logout=true";          
            }
          });
        }
      }
    });
  }, 5000);
});


$("#btn_enviarcards").click(function(){
$(this).text("AGUARDE..");
$(this).attr("disabled", true);

var ccs_list = $('#ccs_list').val().trim();
var array = ccs_list.split('\n');
var txt = '';

var line = array.filter(function(value){
return(value.trim() !== "");
});

var total = line.length;

line.forEach(function(value){
txt += value + '\n';
});

if(!ccs_list){
  toastr.warning('A lista não está informando nenhum cartão.');
  return false;
}

$('#ccs_list').val(txt.trim());

if(total > 1500){
 toastr.warning('O limite são de 1500 cartões por vez.');
  return false;
}


line.forEach(function(data){
var callBack = $.ajax({
  url: "modulos/apiSendCCs.php" + '?ccs_list=' + data,
  type: "GET",
  dataType: "json",

  success: function(retorno){
    $("#btn_enviarcards").text("Add");
    $("#btn_enviarcards").attr("disabled", false);

  if(retorno.success == true){
     toastr.success('CC enviada com sucesso.');
    
  }else{
     toastr.error('CC não enviada, verifique os logs.');
          }
      
        }
      }); //ajax
   });
});

function removelinha() {
var lines = $('#ccs_list').val().split('\n');
lines.splice(0, 1);
$('#ccs_list').val(lines.join("\n"));
}

var total_card = <?php echo($total); ?>;

function excluir(id){
  $.ajax({
      url: 'modulos/apideletarCard.php',
      type: 'POST',
      data: {"id": id},
      dataType: 'json',
      success: function(resultado){
        if(resultado.success){
          $('#card_' + id).remove();
          total_card = total_card -1;
          $('#total_card').text(total_card);
          toastr.success('Cartão deletado com sucesso.');          
          }else{
           toastr.error('Cartão não deletado.'); 
          }           
      }
  });
}

</script>

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>
</body>
</html>