<?php 
require_once('../includes/conexao.php');
require_once('../includes/nav_admin.php');

$data = mysqli_query($conexao, "SELECT * FROM notify");
$total = mysqli_num_rows($data);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Gerenciar Estoque</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="#">Administração</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Notificações</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->
<div class="container h-100">
<div class="row justify-content-center h-100 align-items-center">
<div class="col-xl-5 col-md-6">
<div class="mini-logo text-center my-5">
<a href="index.html"><img src="./images/logo.png" alt=""></a>
</div>
<div class="auth-form card">
<div class="card-header justify-content-center">
<h4 class="card-title">Adicionar Notificações</h4>
</div>
<div class="card-body">
<div class="form-group">
<label>Mensagem que deseja notificar</label>
<input id="msg" type="text" class="form-control" placeholder="Mensagem">
</div>
<div class="text-center">
<button id="btn_notificar" type="button" class="btn btn-success btn-block">Notificar</button>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="content-body">
<div class="container">
<div class="row">
<div class="col-xl-12">
<div class="card">
<div class="card-header">
<h3 class="card-title">Notificações | Total de notificações: <font color="red">1</font></h3>
</div>
<div class="card-body">
<div class="transaction-table">
<div class="table-responsive">
<table class="table table-striped mb-0 table-responsive-sm">
<thead>
<tr>
<th>Mensagem</th>
<th>Data</th>
<th>Publicado por</th>
<th></th>
</tr>
</thead>
<tbody>
<tr id='notify_1'>
<td class="text-success"><b>teste</b></td>
<td>31-01-2022</td>
<td>TERRORDELAS</td>
<td><button class="btn btn-danger btn-sm" onclick='excluir(1)'>Excluir</button></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="../css/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">

$("#btn_notificar").click(function(){
   $(this).text("Notificando..");
   $(this).attr("disabled", true);

var msg = document.getElementById("msg").value;

 $.ajax({
  url: "modulos/addNotify.php",
  type: "POST",
  data: {
    "msg": msg, 
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_notificar").text("Notificar");
    $("#btn_notificar").attr("disabled", false);

  if(retorno.success == true){
    Swal.fire({title:"Sucesso:", icon: "success", text:retorno["message"], toast: true, position: "top-end", showConfirmButton: false, timer: 3000});
    
  }else{
    Swal.fire({title:"Erro: ", icon:"error", text:retorno["message"], toast: true, position: "top-end", showConfirmButton:false, timer: 3000});
          }
      
        }
      }); //ajax
   });

</script>
<script type="text/javascript">

var total_notify = 1;

$(document).ready(function(){

var timer = setInterval(function(){
 
$.ajax({
url: "apiBlock.php",
dataType: 'json',
success: function(retorno){
if(retorno.success === false){
  clearInterval(timer);
  Swal.fire({ title: "Opss!", text: "Novo Login Detectado. Acesso Bloqueado!", icon: "error", confirmButtonText: "OK", confirmButtonClass: 'btn btn-primary', buttonsStyling: false, allowOutsideClick: false, allowEscapeKey: false}).then(function(status){
    if(status.isConfirmed === true){
       location.href = "../?logout=true";      
            }
          });
        }
      }
    });
  }, 3000);
});
   
function excluir(id){
  $.ajax({
      url: 'modulos/apideletarNotify.php',
      type: 'POST',
      data: {"id": id},
      dataType: 'json',
      success: function(resultado){
        if(resultado.success){
          $('#notify_' + id).remove();
          total_notify = total_notify -1;
          $('#total_notify').text(total_notify);
          Swal.fire({ title: "Sucesso", text: resultado["message"], icon: "success", showConfirmButton: false, timer: 3000, toast: true, position: 'top-end'});          
          }else{
          Swal.fire({ title: "Opss!", text: resultado["message"], icon: "error", showConfirmButton: false, timer: 3000, toast: true, position: 'top-end'});           
          }           
      }
  });
}

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>
</body>
</html>