<?php 
require_once('../includes/nav_menu.php');
require_once('../includes/conexao.php');

$usuario = $_SESSION['usuario'];

$sql0 = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$buscausersql = mysqli_query($conexao, $sql0);
$sqldados = mysqli_fetch_assoc($buscausersql);

$sql = "SELECT * FROM usuarios";
$busca = mysqli_query($conexao, $sql);
$totalusuarios = mysqli_num_rows($busca);

$sql1 = "SELECT * FROM notify";
$buscas1 = mysqli_query($conexao, $sql1);
$totalnotify = mysqli_num_rows($buscas1);

$sql2 = "SELECT * FROM cards";
$buscas2 = mysqli_query($conexao, $sql2);
$carddisponivel = mysqli_num_rows($buscas2);

$sql3 = "SELECT * FROM cardsvendidos WHERE usuario = '$usuario'";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos = mysqli_num_rows($buscas3);

$sql3 = "SELECT * FROM cardsvendidos";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos2 = mysqli_num_rows($buscas3);

?>

    <!-- begin::main-content -->
    <div class="main-content">

        <!-- begin::container -->
        <div class="container">

            <div class="page-header">
                <h4>Informações do Painel de Controle</h4>
                <small class=""><?php if($_SESSION['nivel'] == 1){ echo "Olá, <span class='text-primary'>$usuario</span>, seja bem vindo(a), na WebStore desejamos boas compras!";} else{ echo "Olá, <span class='text-primary'>$usuario</span>, seja bem vindo(a), na WebStore desejamos boas compras!";}?> </small>
            </div>

            <div class="row">
                <div class="col-md-12">

    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                     <h6 class="float-right"><span class="text-danger"><?php echo $totalnotify ?></span> notificações</h6>
                                    <h6 class="card-title d-md-flex justify-content-between">
                                        Informações da base:
                                    </h6>
                                    <div class="row">
                                        <div class="col-lg-4 col-md-12">
                                            <div class="card border mb-3">
                                                <div class="card-body p-3">
                                                    <div class="d-flex align-items-center">
                                                        <div class="icon-block mr-3 icon-block-lg icon-block-outline-success text-success">
                                                            <i class="fa fa-shopping-cart"></i>
                                                        </div>
                                                        <div>
                                                            <h6 class="text-uppercase font-size-11">Cartões Vendidos:</h6>
                                                            <h4 class="mb-0"><?php echo $cardsvendidos2 ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card border mb-3">
                                                <div class="card-body p-3">
                                                    <div class="d-flex align-items-center">
                                                        <div class="icon-block mr-3 icon-block-lg icon-block-outline-danger  text-danger">
                                                            <i class="fa fa-credit-card"></i>
                                                        </div>
                                                        <div>
                                                            <h6 class="text-uppercase font-size-11">Cartões Disponíveis:</h6>
                                                            <h4 class="mb-0"><?php echo $carddisponivel ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card border mb-3">
                                                <div class="card-body p-3">
                                                    <div class="d-flex align-items-center">
                                                        <div class="icon-block mr-3 icon-block-lg icon-block-outline-warning text-warning">
                                                            <i class="fa fa-dollar"></i>
                                                        </div>
                                                        <div>
                                                            <h6 class="text-uppercase font-size-11">Meu Saldo:</h6>
                                                            <h4 class="mb-0">R$<?php echo $_SESSION['saldo'] ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card border mb-3">
                                                <div class="card-body p-3">
                                                    <div class="d-flex align-items-center">
                                                        <div class="icon-block mr-3 icon-block-lg icon-block-outline-success text-success">
                                                            <i class="fa fa-cart-plus"></i>
                                                        </div>
                                                        <div>
                                                            <h6 class="text-uppercase font-size-11">Minhas Compras:</h6>
                                                            <h4 class="mb-0"><?php echo $cardsvendidos ?></h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!--- INICIO TABELA NOTIFY ---> 
                                        <div class="col-lg-8 col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-hover mb-0">
                                                    <thead class="thead-light">
                                                    <tr>
                                                        
                                                        <th class="text-white">Informação:</th>
                                                        <th class="text-white">Data de Postagem:</th>
                                                        <th class="text-white">Enviado por:</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
<?php
while($dados = mysqli_fetch_assoc($buscas1)){?>
<tr id='user_<?php echo $dados["card_token"]; ?>'>
<td><?php echo $dados['msg'];?></td>
    <td class="text-warning"><?php echo strtoupper($dados['data']);?></td>                    
    <td><?php echo strtoupper($dados['usuario']);?></td>    
</tr>
<?php } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <!---- FIM TABELA NOTIFY --->


                                       <!-- TABLE -->
<!---<table class="table table-action">
  
  <thead>
    <tr>
      <th class="t-small"></th>
      <th class="t-small">ID</th>
      <th class="t-medium">Date</th>
      <th>Info</th>
      <th class="t-medium">State</th>
    </tr>
  </thead>
  
  <tbody>
    <tr>
      <td><label><input type="checkbox"></label></td>
      <td>1</td>
      <td>27/09/2013</td>
      <td>One little text</td>
      <td class="t-status t-active">Active</td>
    </tr>
    <tr>
      <td><label><input type="checkbox"></label></td>
      <td>1</td>
      <td>27/09/2013</td>
      <td>One little text</td>
      <td class="t-status t-inactive">Inactive</td>
    </tr>
    <tr>
      <td><label><input type="checkbox"></label></td>
      <td>1</td>
      <td>27/09/2013</td>
      <td>One little text</td>
      <td class="t-status t-draft">Draft</td>
    </tr>
    <tr>
      <td><label><input type="checkbox"></label></td>
      <td>1</td>
      <td>27/09/2013</td>
      <td>One little text</td>
      <td class="t-status t-scheduled">Scheduled</td>
    </tr>
  </tbody>
</table> --->
<!-- END TABLE -->
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


        </div>
        <!-- end::container -->

    </div>
    <!-- end::main-content -->
</div>
</div>
    <!-- begin::footer -->
      <footer>
        <div class="container">
      <center>© Copyright 2024 - 2025 Venompcx  Developed by ❤️ venompcx</a></center>
        </div>
<!-- end::main -->
    </footer>
    <!-- end::footer -->

</div>
<!-- end::main -->


<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<!-- Chartjs -->
<script src="vendors/charts/chartjs/chart.min.js"></script>

<!-- Apex chart -->
<script src="vendors/charts/apex/apexcharts.min.js"></script>

<!-- Circle progress -->
<script src="vendors/circle-progress/circle-progress.min.js"></script>

<!-- Peity -->
<script src="vendors/charts/peity/jquery.peity.min.js"></script>
<script src="assets/js/examples/charts/peity.js"></script>

<!-- Datepicker -->
<script src="vendors/datepicker/daterangepicker.js"></script>

<!-- Slick -->
<script src="vendors/slick/slick.min.js"></script>

<!-- Vamp -->
<script src="vendors/vmap/jquery.vmap.min.js"></script>
<script src="vendors/vmap/maps/jquery.vmap.usa.js"></script>
<script src="assets/js/examples/vmap.js"></script>

<!-- Dashboard scripts -->
<script src="assets/js/examples/dashboard.js"></script>
<div class="colors"> <!-- To use theme colors with Javascript -->
    <div class="bg-primary"></div>
    <div class="bg-primary-bright"></div>
    <div class="bg-secondary"></div>
    <div class="bg-secondary-bright"></div>
    <div class="bg-info"></div>
    <div class="bg-info-bright"></div>
    <div class="bg-success"></div>
    <div class="bg-success-bright"></div>
    <div class="bg-danger"></div>
    <div class="bg-danger-bright"></div>
    <div class="bg-warning"></div>
    <div class="bg-warning-bright"></div>
</div>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>

<?php

if(!empty($_GET["id"])){

$id = $_GET["id"];

require_once("../includes/manage.php");
require_once("../includes/conexao.php");

//mysqli_fetch_assoc
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/payments/$id?access_token=$access_token");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("content-type: application/json"));
$retorno = curl_exec($ch);

$dados_pagamento = json_decode($retorno, true);
$status_pagamento = $dados_pagamento["status"];
$valor_pagamento = $dados_pagamento["transaction_amount"];

if($status_pagamento == "approved"){
echo '<script type="text/javascript"> swal("Success", "Seu pagamento foi recebido ❤️", "success"); </script>';
$txt = "Pagamento Recebido com sucesso! $valor_pagamento";
$botoken = "5264933408:AAFR1fyrWFg4zqC989zhoeJyupjLDng7H64";
$data = ['text' => "$txt",'chat_id' => '1296518711', 'parse_mode' => 'html'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));
}else

if($status_pagamento == "pending"){
echo '<script type="text/javascript"> swal("Pendente", "Seu pagamento esta pendente", "warning"); </script>';
}else

if($status_pagamento == "cancelled"){
echo '<script type="text/javascript"> swal("Cancelado", "Seu pagamento foi cancelado", "error"); </script>';
}else 

if($status_pagamento == "rejected"){
echo '<script type="text/javascript"> swal("Recusado", "Seu pagamento foi recusado", "error"); </script>';
}

} //isset id

?>
</body>
</html>