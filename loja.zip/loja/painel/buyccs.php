<?php 
require_once('../includes/nav_menu.php');
require_once('../includes/conexao.php');

$usuario = $_SESSION['usuario'];

$sql0 = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$buscausersql = mysqli_query($conexao, $sql0);
$sqldados = mysqli_fetch_assoc($buscausersql);

$sql = "SELECT * FROM usuarios";
$busca = mysqli_query($conexao, $sql);
$totalusuarios = mysqli_num_rows($busca);

$sql1 = "SELECT * FROM notify";
$buscas1 = mysqli_query($conexao, $sql1);
$totalnotify = mysqli_num_rows($buscas1);

$sql2 = "SELECT * FROM cards";
$buscas2 = mysqli_query($conexao, $sql2);
$carddisponivel = mysqli_num_rows($buscas2);

$sql3 = "SELECT * FROM cardsvendidos WHERE usuario = '$usuario'";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos = mysqli_num_rows($buscas3);

$sql3 = "SELECT * FROM cardsvendidos";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos2 = mysqli_num_rows($buscas3);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Comprar CC's</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Comprar CC's</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">


<div class="col-xl-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">Cartões Disponíveis | Total de Cartões: <?php echo $carddisponivel ?></h4>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="table linked_account">
<thead>
<tr>
<th>BIN:</th>
<th>VALOR:</th>
<th>NOME/CPF:</th>
<th>BANDEIRA:</th>
<th>BANCO:</th>
<th>NIVEL:</th>
<th>PAIS:</th>
<th>AÇÃO:</th>
</tr>
</thead>
<tbody>
                        <?php
                            while($dados2 = mysqli_fetch_assoc($buscas2)){?>
                             <tr id='<?php echo $dados2["card_token"]; ?>'>
                                    <td class="text-warning"><?php echo strtoupper($dados2['bin']);?></td>
                                    <td>R$<?php echo strtoupper($dados2['valorcc']);?>,00</td>
                                    <td><?php if($dados2['cpf'] == 1){ echo "<span class='text-danger'>NÃO</span>"; } else{ echo "<span class='text-success'>SIM</span>"; } ?></td>
                                    <td><?php echo strtoupper($dados2['bandeira']);?></td>
                                    <td><?php echo strtoupper($dados2['banco']);?></td>
                                    <td><?php echo strtoupper($dados2['nivel']);?></td>
                                    <td><?php echo strtoupper($dados2['pais']);?></td>
                                        <td><button id="btn_comprar" class="btn btn-success" onclick="compra(`<?php echo $dados2['card_token']; ?>`)">COMPRAR</button></td> 
                                </tr>
                        <?php } ?>
                            </table>
                        </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
          <center>© Copyright 2021 - 2022 Venompcx v2 Developed by ❤️ </a></center>
        </div>
<!-- end::main -->
    </footer>
</main>


<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

function compra(card_token){
$(this).text("Comprando...");
$(this).attr("disabled", true);

 $.ajax({
  url: "modulos/apiCompra.php",
  type: "POST",
  data: {
    "card_token": card_token, 
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_comprar").text("COMPRAR");
    $("#btn_comprar").attr("disabled", false);

  if(retorno.success == true){
   toastr.success(retorno['message']);
  setTimeout(function(){
  window.location.href = "mypurchases.php";
    }, 5000);
  }else{
    toastr.error(retorno['message']);
          }
        }
   }); //ajax
}

</script>

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<script type="text/javascript">
toastr.success("Desejamos boas-compras para você.")
</script>
<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>

</body>
</html>