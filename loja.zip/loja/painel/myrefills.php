<?php 
require_once('../includes/conexao.php');
require_once('../includes/nav_menu.php');

$chave = $_SESSION["chave"];
$data = mysqli_query($conexao, "SELECT * FROM historico WHERE access_key = '$chave'");
$total = mysqli_num_rows($data);

?>
    <!-- begin::main-content -->
    <main class="main-content">

        <div class="container">

            <!-- begin::page-header -->
            <div class="page-header">
                <h4>Suas Recargas</h4>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="#">Painel de Controle</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Suas Recargas</li>
                    </ol>
                </nav>
            </div>
            <!-- end::page-header -->

            <div class="row">
                <div class="col-md-12 lg-12">

                    <div class="card">
                        <div class="card-body">
                            <table id="example2" class="table table-striped">
                                <thead>
                                            <tr>
                                                <th class="text-danger">ID</th>
                                                <th>Data</th>
                                                <th>Status</th>
                                                <th>Valor</th>
                                            </tr>
                                </thead>
                                <tbody>
<?php while($dados = mysqli_fetch_assoc($data)){?>
                <tr>
     <th scope="row"><?php echo $dados["id"]; ?></th>
     <td><?php echo ($dados["data"]); ?></td>
       <td><?php echo strtoupper($dados["status"]); ?></td>
        <td>R$<?php echo $dados["valor"]; ?></td>
              </tr>
<?php 
 } 
?>
                            </table>
                        </div>
                    </div>
 

    <!-- end::main-content -->
    <!-- begin::footer -->
    <!-- end::footer -->
      <footer>
        <div class="container">
          <center>© Copyright 2021 - 2022 PladixStore v2 Developed by ❤️ PladixOficial</a></center>
        </div>
<!-- end::main -->
    </footer>
</main>

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<script type="text/javascript">
swal("Aviso", "Por favor, se houver algum erro/problema no seu depósito, entre em contato com o @PladixOficial e resolva seu problema o mais breve possivel!", "warning");
</script>
<!-- DataTable -->
<script src="vendors/dataTable/jquery.dataTables.min.js"></script>
<script src="vendors/dataTable/dataTables.bootstrap4.min.js"></script>
<script src="vendors/dataTable/dataTables.responsive.min.js"></script>
<script src="assets/js/examples/datatable.js"></script>

<!-- Prism -->
<script src="vendors/prism/prism.js"></script>

<!-- App scripts -->
<script src="assets/js/app.min.js"></script>
</body>
</html>