-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 17/07/2024 às 04:00
-- Versão do servidor: 10.11.8-MariaDB-cll-lve
-- Versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `u769608658_Venix`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `auth_recaptcha`
--

CREATE TABLE `auth_recaptcha` (
  `id` int(11) NOT NULL,
  `publick_key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `secret_key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `maps_key` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `card` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mes` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ano` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cvv` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valorcc` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cpf` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bin` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `pais` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bandeira` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nivel` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tipo` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `banco` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `vendendor` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `card_token` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cardsvendidos`
--

CREATE TABLE `cardsvendidos` (
  `id` int(11) NOT NULL,
  `card` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `mes` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `ano` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cvv` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valorcc` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nome` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `cpf` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `banco` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nivel` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `bandeira` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `card_token` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `order_token` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `data_c` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cardsvendidos`
--

INSERT INTO `cardsvendidos` (`id`, `card`, `mes`, `ano`, `cvv`, `valorcc`, `nome`, `cpf`, `banco`, `nivel`, `bandeira`, `usuario`, `card_token`, `order_token`, `data_c`, `status`) VALUES
(194, '5526933126180823', '05', '2026', '007', '5', 'Alícia Daniela Nair da Paz', '657.438.057-09', 'BANCO SANTANDER BRASIL, S.A.', 'BUSINESS', 'MASTERCARD', 'admin', 'cd0ee150a86fe5e0c0b05536123d4a8b', 'NjIxMmFiNDA3YTg2Yg==', '1645391256', '2'),
(195, '5429350185220754', '05', '2025', '225', '5', 'Aline Sara Fogaça', '762.685.372-54', 'BANQI INSTITUICAO DE PAGAMENTO', 'PREPAID', 'MASTERCARD', 'admin', '31940e8564c81ef80972411cee8b0f36', 'NjIxMmFkMTU4M2U2Yw==', '2022-02-20 18:05:25', '2');

-- --------------------------------------------------------

--
-- Estrutura para tabela `gift`
--

CREATE TABLE `gift` (
  `id` int(11) NOT NULL,
  `gift` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `status` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `valor` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `gift`
--

INSERT INTO `gift` (`id`, `gift`, `status`, `valor`, `usuario`) VALUES
(2945, 'RXEU-29PJ-I0SW-EEU5', '', '', ''),
(6273, '5VBH-USHK-AAHQ-2ENP', '', '', ''),
(6510, 'P6WR-9YA0-890F-FYIS', '', '', ''),
(9588, 'EZLY-ED2C-PF14-LGCH', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico`
--

CREATE TABLE `historico` (
  `id` varchar(15) NOT NULL,
  `access_key` varchar(40) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `data` varchar(25) NOT NULL,
  `status` varchar(15) NOT NULL,
  `valor` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `historico`
--

INSERT INTO `historico` (`id`, `access_key`, `data`, `status`, `valor`) VALUES
('17843284636', '5791d6e744363e02933dfa75b40fb077', '29-10-2021 18:27:28', 'pending', 15),
('17899074054', '478f4c39d1a32a2dcb4237c25af4431c', '01-11-2021 17:27:19', 'approved', 30),
('17966035577', '86ecb00f59e58507a0ceb2d5f8cf5a02', '04-11-2021 20:19:56', 'approved', 10),
('20339458267', '856895e517df761b892c376d239bfe0d', '20-02-2022 17:34:48', 'approved', 5),
('20340113504', '856895e517df761b892c376d239bfe0d', '20-02-2022 17:43:27', 'approved', 1),
('20394010596', '8700be489c51c97cb1a33e0f1e32472b', '23-02-2022 05:43:16', 'approved', 7),
('20409084215', '0020a8bf4e9484ac7eefb9d6f834ac6c', '23-02-2022 17:46:29', 'approved', 1),
('20409200459', '0020a8bf4e9484ac7eefb9d6f834ac6c', '23-02-2022 17:50:43', 'approved', 2),
('20410459088', '44a4919ecc6a43ae530c9fc729a5b309', '23-02-2022 18:38:40', 'approved', 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `notify`
--

CREATE TABLE `notify` (
  `id` int(11) NOT NULL,
  `msg` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `data` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `notify`
--

INSERT INTO `notify` (`id`, `msg`, `data`, `usuario`) VALUES
(30, 'FAÃ‡A SUAS RECARGAS AUTOMÃTICAS!', '20-02-2022', 'admin');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tabelaccs`
--

CREATE TABLE `tabelaccs` (
  `ID` int(11) NOT NULL,
  `Nivel` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `Valor` varchar(40) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(35) NOT NULL,
  `senha` varchar(40) NOT NULL,
  `saldo` varchar(10) NOT NULL,
  `creditos` varchar(10) NOT NULL,
  `chave` varchar(40) NOT NULL,
  `nivel` int(5) NOT NULL,
  `lives` int(5) NOT NULL,
  `live_card` int(10) NOT NULL,
  `live_login` varchar(10) NOT NULL,
  `auth_token` varchar(40) NOT NULL,
  `idtelegram` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `senha`, `saldo`, `creditos`, `chave`, `nivel`, `lives`, `live_card`, `live_login`, `auth_token`, `idtelegram`) VALUES
(492, 'admin', '0497dcfc4c89f9bbf6ca54bcdaf21de4', '1914', '', '856895e517df761b892c376d239bfe0d', 1, 36, 0, '', 'c58f8f4740a6078bac18e39aac2fa550', '1296518711'),
(494, 'Teste', '698dc19d489c4e4db73e28a713eab07b', '0', '', '9f91cca0e51e718eed0a409eb74fc12c', 0, 0, 0, '', '0a9f89d398479dd09d9d3e55a16fda5b', '1296518711'),
(495, 'kingsman', 'c31d6a6810e2a8e86fb3b645f860d00d', '0', '', '74c07cefa310bbdf6a71a63f2f99a04a', 0, 0, 0, '', '615f223512a17d061a82ba16eeb1e7ef', '1296518711'),
(496, 'Manel', '81dc9bdb52d04dc20036dbd8313ed055', '0', '', '2aec4851456f1378db5752bb00ae0cbb', 0, 10, 0, '', '457ef7adf91549b2b8875d1a46929457', '1296518711'),
(497, 'luiz', '81dc9bdb52d04dc20036dbd8313ed055', '0', '', 'a7b9015c9ef859c215a67fb7bff1d132', 0, 0, 0, '', 'f541e91367bffb168be7b7cee51b453d', '1296518711'),
(502, 'Sougayjkkk', '1e48c4420b7073bc11916c6c1de226bb', '0', '', 'edec5edf71959fc58559b9a8a9bbcbd5', 0, 0, 0, '', '812d2bd9cfe9d3d42e9f9628b73ac43c', '1296518711'),
(505, 'hzninfo', '019c0d1ed1ba82441c8b941ff0498cf4', '0', '', '36d1f0ea4606572ad5f7be67f1b07ca4', 0, 0, 0, '', 'f6880bdb2603ea482ae2c9d7f959b01a', '1296518711'),
(506, 'Dan', 'c4ca4238a0b923820dcc509a6f75849b', '0', '', '6ef7caf8d33c61841c80ae9669f5910d', 0, 0, 0, '', '401985b970f36df4631fa572289d713d', '1296518711'),
(508, 'menato', '1e48c4420b7073bc11916c6c1de226bb', '0', '', '9dd7af863023827a2531dcdde93f9e3b', 0, 0, 0, '', 'ed0c8bb225eec903cc7a8c9cbd2fcf49', '1296518711'),
(510, 'Igor', '1e48c4420b7073bc11916c6c1de226bb', '0', '', 'da7aea54a77378a492ae5ac03ef31a4e', 0, 0, 0, '', 'be929eb4bc3b38c5e2f0b80482fb88af', '1296518711'),
(511, 'satoru', '95f190a0581e1bd096caebe71d0bcc21', '0', '', 'fc5018bc161a039acad02bb0fe70ff06', 0, 0, 0, '', 'f5421b25a50aa7e9e3b2df11881f2dab', '1296518711'),
(512, 'adm', '36e1fbc074c7afd36805975c278284d3', '0', '', '92577f238f3abf1e6d9e4a4c089d9241', 0, 0, 0, '', 'bff133d2c0002c56ab53905b3760d818', '1296518711'),
(513, 'abiugu', 'c81c2b9e997a81f84838cd8e60b93a01', '0', '', '418614d29903183cda0dc98abb784a6b', 0, 0, 0, '', '8383e3ad1d14c2a6d14dacd947b5c9c9', '1296518711'),
(514, 'offzinho', '25bc09f18177c99e393d833c290700e4', '0', '', '2c17dd2ce805ee744c249bc3fc66aac2', 0, 0, 0, '', '0a7def784388f4994cf3e16a0314b64a', '1296518711'),
(515, 'Dryrtan', '7d7743b602eed950009fb95d091ab762', '0', '', 'd22f084f74dd4c6662332fcc163998f4', 0, 0, 0, '', '279ad98d8c44cf929a06168275e816ea', '1296518711'),
(516, 'Brunor', '8755f00e52a678081cb1b4837f054954', '0', '', 'bd7e5f99052521c455e3ce3c18242e34', 0, 0, 0, '', '', '1296518711'),
(517, 'Luís ', 'b9f35816f460ab999cbc168c4da26ff3', '0', '', 'fdc7d6abdf8438007b39aaecd04a9846', 0, 0, 0, '', '5c37c2686b7638b01f896cd316f7475b', '1296518711'),
(518, 'DefaultHacking', '7e396dd89d6cb350999276cb8a1156d2', '0', '', '27ca1ed781c4c8980da8dd2ccab217b9', 0, 0, 0, '', '623fb4b59bfb49dce48be9e887f55147', '1296518711'),
(519, 'maoubelzebu', 'f305bc7356edefbbd3a3c40bfe050605', '0', '', '8fd5963a8c33809406a391dd32a0401f', 0, 0, 0, '', 'd0a13dda914dce09646537f924d01f74', '1296518711'),
(520, 'andredeni', '861699495f8299283673bcae34f64660', '0', '', '2a9553b91c0a7f97ee1fe2cdd5206ec2', 0, 0, 0, '', 'a39915b043453a8ac614efe0cfc0bcf8', '1296518711'),
(521, 'badthur', '2dd98cb7920dbb1af9efdac53f09de2c', '25', '', '515c2bf0e6e1af78fd4e02a73163253e', 0, 9, 0, '', 'eeff70fdd1ef4a7a378053795f38b417', '1296518711'),
(522, 'gabrielcabeca', '81dc9bdb52d04dc20036dbd8313ed055', '0', '', 'b13ce7e19af0a3156cf84434e8979d1e', 0, 0, 0, '', '28b3cdcc2b1c592fc6aa5fa1a6ae900f', '1296518711'),
(523, 'isabel-de-queiros@tuamaeaquelaursa.', '8cbc57a546f56a4a11a7b0992714b622', '0', '', '472bc4d40ddc662a93f74f91f0822bf5', 0, 0, 0, '', '', '1296518711'),
(524, 'haxo\' or 1=1; #', 'f46d6ec3b209f243aa7a31e1ee61ab03', '0', '', '6c446d0a92c27e9e3d2532e92f55390d', 0, 0, 0, '', '9b1fe4c16ee4cbf0513965a76a89376e', '1296518711'),
(525, 'RodrigoFaro', '1563c108920f81d6290e9142972e7240', '0', '', '768ce3b9f5a9330f168c5d49a5d477c6', 0, 0, 0, '', '1e80b244f5743567b1342d80e0d6d5d2', '1296518711'),
(526, 'MSHallx', '1cd452f95e825702aee1bebf6de99733', '0', '', 'b618bf38f341a427ac54d784667eb7dd', 0, 0, 0, '', 'a40dd9fa746aab037c4c3879f10c96d2', '7'),
(527, 'brabox', '50df14939363759a76955fceda38823b', '0', '', '55cddda2801f507f58ff09a7509a8e21', 0, 0, 0, '', '17fb13048e594db2a3d0d64a964b9d7d', '1287275383'),
(528, '?????S?A?M?U?R?A?I? X???? ', 'f547c5e3b2ce47e9539fcb2f44c6f515', '0', '', 'a5e15e3a6e4e035a85f022004b134e46', 0, 0, 0, '', '', '2001569334'),
(529, 'batmanzl', '4a5736364589b10fba111b1bd4a670bd', '0', '', 'db7ee5029cad193eb615bbbf8f5096e5', 0, 0, 0, '', 'cebd839e20d3d0315814e209044242a6', '1356244450'),
(530, 'Tantan66', 'e103b9d7fffa00bcd3a84213875a70c8', '0', '', '5395bec822b2f7fa62b914f8279f723d', 0, 0, 0, '', '', '51999880478'),
(531, 'Tantan666', 'ca0ac6f71f426aa63a4bbfabea06d1a2', '0', '', 'ac22a352c9d2847716270f327dd5e07c', 0, 0, 0, '', '295b25d5f5b8aa067ac8f2bfc785c8aa', '51666'),
(532, 'Rey', 'fcea920f7412b5da7be0cf42b8c93759', '0', '', '944424df23e5d30aad81a0f8921f3a0e', 0, 0, 0, '', '95ad5d1c5c4c6574fc356205c80be9cf', '2134665764'),
(533, 'rznpcx', '8a652c6a9e3145ef3d571c6bce1650d6', '0', '', 'c2bbfc2126502901636a51abbdeb77a1', 0, 0, 0, '', '6dc73953575b3a44b025976bcc8e91d6', '1999084642'),
(534, 'Jorgg', '6d071901727aec1ba6d8e2497ef5b709', '0', '', '17325669c2feb0a0831dc0979f528be1', 0, 0, 0, '', '27d887a7a2095154ffe8f17ae377ea37', '101010'),
(535, '?????S?A?M?U?R?A?I? X????', 'b290332925fbf180f3299be97ef1ef77', '0', '', '2feecdb3c4f99efdc278193f1d525b64', 0, 0, 0, '', '', '2001569334'),
(536, 'Mnrzin_Ws', 'fcea920f7412b5da7be0cf42b8c93759', '0', '', 'd87c97576cdccdd47ebfa7f3453170fc', 0, 0, 0, '', '1bba6ba262c23d01a49b18fb7e508c2a', '2001569334'),
(537, 'kaiky', '202cb962ac59075b964b07152d234b70', '0', '', '9c8af13ddd6e20056181c8f535b41df4', 0, 0, 0, '', '78f5c5a9de95694ba0752520e129a79c', '1001768892332'),
(538, 'Kuslov', '4e0d39a0e0cc3c978ad3a87301f7d6db', '0', '', 'a755ea210b74d37b78e1afcbbaf2bba1', 0, 14, 0, '', 'ca76898066cb1b9b6458714645d737c1', '1715313143'),
(539, 'Myers', 'e10adc3949ba59abbe56e057f20f883e', '30', '', 'b9849b61c88c2789bc9fd137d4556f2b', 0, 0, 0, '', '26af485f4fdcaaac24832c463581e555', '1199852455'),
(540, 'haxo\' or 1=1; #1', '290ba0b5116dac8e1a4650addeda5ecd', '0', '', 'd82f1a969bdfeaef41f0503fd078c03e', 0, 0, 0, '', 'd555b9e94fa7ec45343f5296e4e572c0', '14090612'),
(541, 'badthurr', '8ae05587eed61034e93265eea7fbcfab', '0', '', 'fedcdcd01244e4b35a133d0c09980701', 0, 0, 0, '', 'cdda980f2b65899d2e0f59688630e148', '1001768892332'),
(542, 'haxo\' or 1=1; #11', '2fcdd9257a83352170497dcb9ffa808e', '0', '', 'd449029a61ce3f3e7f2407b2f53c2ad9', 0, 0, 0, '', '12896186936716b381eb15850d628341', '1'),
(543, 'veinho', 'fb51bdc4b99e2bd881862c8f76d404d4', '0', '', '144c60c512bb8060305c720c22e12587', 0, 0, 0, '', '2762c0c39fc736fb2ba77b11cffa0f09', '1001768892332'),
(544, '<tg-spoiler>hehe</tg-spoiler>', 'e10adc3949ba59abbe56e057f20f883e', '0', '', 'f148ab910b7babdc54a405c4925e64e7', 0, 0, 0, '', 'ef5e53442d6c99d1059915b4137d742c', '666666666'),
(545, 'Pladix Gay', 'e10adc3949ba59abbe56e057f20f883e', '0', '', 'b151650505cf3a8b5ef4b19fd277e03c', 0, 0, 0, '', '5af29e61b5d5a9ed2270e1fbac50cca3', '1296518711'),
(546, 'karlluspit', 'a360e3b85147ef2bae786f3fc7fc6c7e', '0', '', '36be5706f2e5428aa613d51a649d0c05', 0, 0, 0, '', '', '-1001768892332'),
(547, 'ViniCarding', 'bc7316929fe1545bf0b98d114ee3ecb8', '0', '', '388e797bee87ecf11d7a9988d174b69d', 0, 0, 0, '', '533defd4aaa986a9ce3f7d38cf3e1387', '1010101010'),
(548, 'Tan666', 'ca0ac6f71f426aa63a4bbfabea06d1a2', '0', '', 'ce3bf35d89c048e15bfca32e162a7fd6', 0, 0, 0, '', '4ff6417b2d5269571dadc61152050599', '2096383120'),
(549, 'evertin244', 'b93a6e485ea8030e7137fd4e39889e6d', '0', '', 'eba423776abbcf066e606aceece01d4a', 0, 0, 0, '', 'cf60ce0475a78e3a8b719c4fff29178c', '1001768892332'),
(550, '@AceStrycker', '81dc9bdb52d04dc20036dbd8313ed055', '0', '', '510d185fbca036a87c93b6beb7c6220b', 0, 0, 0, '', '4e425d331af49a52593c745c6731d0e0', '747223244'),
(551, 'justakashi', '4c86144a8f0adf20a1d3907896869ed4', '0', '', '2e7af66829bf890dfca73ce537442183', 0, 0, 0, '', 'a78c7c5fb894b72f1d13d7227f28bdd6', '141484'),
(552, 'Gabriel', '74d58bdb240515317c74fd20d35dfdea', '0', '', 'ef5a5c94b2b77da54ac3f5f8fd760bca', 0, 0, 0, '', 'ae3233ce4c2b24a304d405b22562584b', '1880259499'),
(553, 'Tapout', '56f7138fe1fd38d9aab430895e5f1391', '0', '', '25bc7a0c5c07d8cf4547c1985cb27254', 0, 0, 0, '', '090472233885eec9d5ea2f5885d08333', '3122489'),
(554, 'Bhxtz', '3d0f9e84deaa973e8e182e9c0e620232', '0', '', '7027b24be5af81063e3b0180dad4da29', 0, 0, 0, '', '7d52b1983aaa0c8b91fecb67bfea869b', '4677577432'),
(555, 'Abiugu99', '15c516ad9e15369d5881aca8a9109577', '15', '', 'abb1eaaf311a724ad049a1c177e1aa76', 0, 0, 0, '', 'e133ccfe958adaae46dcd51dc8ad9013', '421752275'),
(556, 'mgforce13', '7f7a7210cf644aed4b463187c35d88b3', '0', '', 'f33da4c1efe6977066abc5ea3c543ebf', 0, 0, 0, '', '8363b7a40d2a99675d61c4ab23e8d8f3', '1469109871'),
(557, 'Enri', '375e235ca2ca8f11833ffcbc97c13981', '25', '', 'e64a4abcb8b9e7e16788136f8ae6c7ea', 0, 0, 0, '', 'b8c4d7336fcd2e57cf5c7dc0973ae08d', '1740949494'),
(558, 'AnakinSA', '56b40dbf97bbb0137fbc5ac446a3d58e', '0', '', '018fdcad2c2233d0100699f2fc9e7fa7', 0, 0, 0, '', '787e6f234dbba8720ce95f4fea4b3197', '324543535'),
(559, 'KANEzinn', '528714ed7b03ae5558aa8ad84ea1edc9', '0', '', '6f47b362c15deb47e45b8f1169d76a48', 0, 0, 0, '', '6669ffab688e9fcf6f2580a3cdf7d79a', '544121682'),
(560, 'cadu_off', 'dbedab7d8b9c89bf7bb43054ed143714', '0', '', 'e3fc43e2d31e3f8d479dcdb7a557a902', 0, 0, 0, '', 'cd0cd9999d9d366351a9e06232116011', '1487484636'),
(562, 'Golden71', '95d309f0b035d97f69902e7972c2b2e6', '0', '', 'cc73747d3ed4a127293b1eb0619882a1', 0, 0, 0, '', 'd430771988b5de354935b325a816a421', '1001768892332'),
(563, 'gamer777', '043892cc4bb3afdd4a24d0228a9dfb48', '0', '', '88aa7436738707fc4539a63ecdf94fc8', 0, 0, 0, '', 'c77ec9dc8fd6439c17cabf3f5bb16596', '1763314030'),
(564, 'Braba2021', '7d847f0e474da22a793ef63189849d14', '0', '', 'd9fca62e1e8d973d4f2b51fc50e11bbd', 0, 0, 0, '', 'ab5c3f20e283c7533e858bcbba4b8771', '8898851888'),
(565, ' if(now()=sysdate(),sleep(0),0)/*\'X', '03bb211bc7ff0720fee011173d5a5536', '0', '', '6bc245fea961a2934d9e95c092cd0a6d', 0, 0, 0, '', '', '124314'),
(566, ' if(now()=sysdate(),sleep(0),0)/*\'X', '03bb211bc7ff0720fee011173d5a5536', '0', '', '4e0183d1c9de70c6a918c0b44504de86', 0, 0, 0, '', '', '4324343'),
(567, ' if(now()=sysdate(),sleep(0),0)/*\'X', '03bb211bc7ff0720fee011173d5a5536', '0', '', '171ff7ec9ab8010be7c0708e8dfd5c38', 0, 0, 0, '', '', '3543453'),
(568, 'CheckersReserva', '8fd38fc5f341013b42a4c7bbad880490', '0', '', '3d3d3a802a9679907bffa15d3b9d43d1', 0, 0, 0, '', 'f9ebf6a14914e6ecb1809ce4cf15edc8', '1'),
(569, 'Pladixpedo', '6b1da2896e08d638d9ee4671941de756', '0', '', 'd466f32a293f06470052fc1f84a0722e', 0, 0, 0, '', 'cc33aced0b4f91144e063d1e4f318ea6', '1234'),
(570, 'Upccs', 'da182c0b9dbc2d2ec066321dd4097a9c', '0', '', '887cd59dc953ad34142aebcfab93c504', 0, 0, 0, '', '18a8e63a84e550044e39720877c7f189', '2006496649'),
(571, 'Pernalonga', '560f139be4d03420e6d991ad6125402c', '0', '', '227a9d6dfbb25b0573c0fb3fa7e9cae7', 0, 10, 0, '', '0aa653f50789aceb32b1c27a88c8eca9', '5053311974'),
(572, 'macropac', '9051d1ff9087a63132bf078fde82a2f9', '0', '', 'c95e0ded88eab6b6eccd78bb09d0ff0b', 0, 0, 0, '', '3f67b6377a8d12ec3cc1995f9f8ca770', '5'),
(573, 'D3f4ltUser', '7ebfe4ffd46994761d642c17f829dc21', '0', '', 'd80577cbcf5cbceadf6f6cb4a8359ef1', 0, 0, 0, '', '8ec14ac7081003400f225432b9737ec0', '1804448115'),
(574, 'kgaarkk', '1e48c4420b7073bc11916c6c1de226bb', '1', '', '855165212d18c70045f0c85724f3c9fd', 0, 0, 0, '', '', ''),
(575, 'xpx22', 'c8db0979bd866d9bb822ce3ae7c7da33', '0', '', 'be1dc359be14bc60695319d45c2284e9', 0, 0, 0, '', '866c9a7ff968f9788858977d04c0ecc2', '-1'),
(576, 'Daianednv', '237ef03243d35254da3f46baf6bbbc7b', '0', '', '50bb68f33deff4c7e006270b9778f38b', 0, 0, 0, '', 'c337a6ce2820090e826f4980a5eedd30', '11989269567'),
(577, 'terrordelas', '3a232003be172b49eb64e4d3e9af1434', '0', '', '4156205cc5621f85b9ec370b5e1c6e0a', 0, 0, 0, '', 'f348955891e47aebe71f09c6d41860d4', '92723232'),
(578, 'Marcelo2020', '5f5049ada5dff22784f45a5e8bf4c4f4', '0', '', 'e4989354f851e98d929ae0d59ad0fc66', 0, 0, 0, '', 'f2b0835c9c7dad757dc1928bc45e0151', '5054096952'),
(579, 'Allif', '1f1b5dbea13dd511e8ba4dbea4e075d2', '0', '', '8a7ecb3ef1e88f9cfb5680877ca6bbf7', 0, 2, 0, '', '12842a8900e39a85aaa460b0dccf9b15', '1724347192'),
(580, 'Kanezzin', '528714ed7b03ae5558aa8ad84ea1edc9', '15', '', '5e1cfe86a08b16f98e5753d9dcb5f201', 0, 1, 0, '', '383740935bbf5a520f34499d0dbde880', '544121682'),
(581, 'Jorgao', '81dc9bdb52d04dc20036dbd8313ed055', '0', '', '30d9cce006be88511952368fae4e99f6', 0, 0, 0, '', 'e853b099b0649e81df36153dca42625b', '2388666'),
(582, 'APRENDIZ171', 'dfaf045a0c6d6b6803d5aa9ee4c97d7a', '0', '', '8fcc6be0a1a6ba15e770e31374a2a4ef', 0, 0, 0, '', '51437982ddcf4104cfcdbbf801513be8', '2017787570'),
(583, 'Jigor', 'e2fc714c4727ee9395f324cd2e7f331f', '0', '', '4b8ddbba287aa00bf0bfdc9c8b72426f', 0, 0, 0, '', '5407dfd3282d51a15507176fceb4b8a1', '8531'),
(584, 'Ares', '1e48c4420b7073bc11916c6c1de226bb', '0', '', '616f4ba04a18256d5910cb2a89fe4c11', 0, 0, 0, '', 'e6956aa7ffffb92098175ef4d525b806', '5542988314626'),
(585, 'Jp13', '54e1dea37c771445e232dfcc02f68da9', '0', '', 'd3301a8365b453c0a71b1a3f28ced212', 0, 1, 0, '', '3528161b3b361091baac23986606841e', '2087619095'),
(586, 'Lk', '6531401f9a6807306651b87e44c05751', '0', '', 'c5a82372a850618768d1c4f6aa0aec24', 0, 0, 0, '', 'a9951fcb3666b9da8b13b59756bc5156', '1901066599'),
(587, 'Ita_87', '85b16a4355362aa58be61bb55e283574', '0', '', '4e1ae3dcfdca43185458f2b297ecb0f5', 0, 0, 0, '', '512a165be2d0baacaecb3ca58e177b55', '19877'),
(588, 'diablero', '2fe7f5008cfbdb22677a60a5eb3e90b6', '0', '', '55b2470bc1f01d5ca4b2ed7aa5b77b4b', 0, 0, 0, '', 'a3f59374dad0fa8ad9a99d8032c30db1', '5143385772'),
(589, 'Jhon', '09b5010db4dd714bb26b6c4ccc7cd7c9', '0', '', '6503817838356c6691d06ae32ff49b0b', 0, 0, 0, '', '5f247d3e3348d06678dc110af9952da0', '1415552514'),
(590, 'chicaotv', '07d6fbc810971db582347f34a0b0b00d', '14', '', '8700be489c51c97cb1a33e0f1e32472b', 0, 0, 0, '', '350a63949b43b1a1f56d52eec0e73618', '31972100449'),
(591, 'Lmrbr', '51de5d3f04ea6031306a4401f8113f6a', '40', '', 'cf5ab6ff00982d7f0d1977c2c0dac783', 0, 0, 0, '', '1f388616214b0b750632a69789fca5d6', '9185'),
(592, 'Maria silva', '9f9f0cbc5a007fb3ac5aea97acab210a', '0', '', '0f0c0070ca6fcc6b8944f0c451574f1e', 0, 0, 0, '', '76c122a436e64c0fed194913feb2b573', '1728354997'),
(593, 'reurypcx ', '8a652c6a9e3145ef3d571c6bce1650d6', '6', '', '44a4919ecc6a43ae530c9fc729a5b309', 0, 0, 0, '', 'a1c59d43d65c9d49d23ef565ad4fda35', '1999084642'),
(594, 'pladix2', '4badaee57fed5610012a296273158f5f', '6', '', '0020a8bf4e9484ac7eefb9d6f834ac6c', 0, 0, 0, '', 'dd2f0e769b00f13c397c80fbedc8a811', '2000000000'),
(595, 'arnox7', '672006eb2c2aa4a86373fcc0ac9a0399', '0', '', '5f810591abeacc9a622485fde2b3f86b', 0, 0, 0, '', 'd1d090ea09f0f8bc98304685d2dcebe7', '1753943898'),
(596, 'haxo\' or 1=1; #111', 'f46d6ec3b209f243aa7a31e1ee61ab03', '0', '', '41d1bae77ec34d4c1350a63088200b19', 0, 0, 0, '', '944c14d8b2c98b3dfa953e7d2de001ea', '11'),
(597, 'cudegrilo', '0c38e5350c12db1ba1b3dc85969a7e96', '0', '', '9482320ceb559720ffa3be3c3b85c090', 0, 0, 0, '', '3614b25d5f800a5d3311a03a06368185', '1343214214');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `auth_recaptcha`
--
ALTER TABLE `auth_recaptcha`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `cardsvendidos`
--
ALTER TABLE `cardsvendidos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `gift`
--
ALTER TABLE `gift`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `notify`
--
ALTER TABLE `notify`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tabelaccs`
--
ALTER TABLE `tabelaccs`
  ADD PRIMARY KEY (`ID`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auth_recaptcha`
--
ALTER TABLE `auth_recaptcha`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2376;

--
-- AUTO_INCREMENT de tabela `cardsvendidos`
--
ALTER TABLE `cardsvendidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT de tabela `gift`
--
ALTER TABLE `gift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9960;

--
-- AUTO_INCREMENT de tabela `notify`
--
ALTER TABLE `notify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `tabelaccs`
--
ALTER TABLE `tabelaccs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=598;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
