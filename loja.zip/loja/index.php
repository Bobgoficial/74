<?php
error_reporting(0);
if($_GET['logout'] === "true"){
session_start();
session_destroy();
}
?>

<html lang="pt-br">
<head><meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PladixStore | Página de Login</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://acegif.com/wp-content/gifs/raining-money-42.gif"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="vendors/bundle.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="assets/css/app.min.css" type="text/css">
    <script src="https://www.google.com/recaptcha/api.js?render=6LdqoBEqAAAAAEOGum8mtEAerrVbs0HQ31gj1HWY"></script>
</head>
<body class="form-membership dark">

<!-- begin::preloader-->
<div class="preloader">
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="50px" height="50px" viewBox="0 0 128 128"
         xml:space="preserve">
        <rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>
        <g>
            <path d="M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z"
                  fill="#000000" fill-opacity="1"/>
            <animateTransform attributeName="transform" type="rotate" from="0 64 64" to="360 64 64"
                              dur="500ms" repeatCount="indefinite">
            </animateTransform>
        </g>
    </svg>
</div>
<!-- end::preloader -->

    <!-- logo -->
    <!--- <div id="logo">
        <img class="logo" src="https://acegif.com/wp-content/gifs/raining-money-42.gif" alt="image">
        <img class="logo-dark" style="width: 60%; height: 120%;"src="https://acegif.com/wp-content/gifs/raining-money-42.gif" alt="image"> 
    </div> --->
    <!-- ./ logo -->
    
   <!--- <div id="logo">
        <img class="logo" src="https://acegif.com/wp-content/gifs/raining-money-42.gif" alt="image">
        <img class="logo-dark" style="width: 60%; height: 120%;"src="https://acegif.com/wp-content/gifs/raining-money-42.gif" alt="image"> 
    </div> --->
    
    <div class="form-wrapper">
    <h5 class="text-primary">PladixStore - Página de Login</h5>
    <!-- form -->
    <form>
        <div class="form-group">
            <input type="text" id="usuario" class="form-control" placeholder="Digite o seu usuário..." required autofocus>
        </div>
        <div class="form-group">
            <input type="password" id="senha" class="form-control" placeholder="Digite a sua senha..." required>
        </div>
        <div class="form-group">
            <input type="hidden" id="idtelegram" class="form-control" placeholder="Informe a sua ID do Telegram..." value="-1001768892332" required>
        </div>
        <div class="form-group d-flex justify-content-between">
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" checked="" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Lembrar-me</label>
            </div>
        </div>
        <button id="btn_login" class="btn btn-primary btn-block">Entrar</button>
        <hr>
        <p class="text-muted">Não tem seu login?, clique abaixo?</p>
        <a href="cadastro" class="btn btn-outline-light btn-sm">Clique aqui!</a>
</form>
<br>
</div>

<!-- Plugin scripts -->
<script src="vendors/bundle.js"></script>

<!-- App scripts -->
<script src="css/jquery.min.js" type="text/javascript"></script>
<script src="assets/js/app.min.js"></script>

<script type="text/javascript">
$("#btn_login").click(function(){
   $(this).text("Processando...");
   $(this).attr("disabled", true);

   var usuario = document.getElementById("usuario").value;
   var senha = document.getElementById("senha").value;
   var idtelegram = document.getElementById("idtelegram").value;

   grecaptcha.ready(function(){
       grecaptcha.execute("6LdqoBEqAAAAAEOGum8mtEAerrVbs0HQ31gj1HWY", {action: 'homepage'}).then(function(response){
           $.ajax({
               url: "auth/login.php",
               type: "POST",
               data: {
                   "usuario": usuario, 
                   "senha": senha,
                   "idtelegram": idtelegram,
                   "g-recaptcha-response": response
               },
               dataType: "json",
               success: function(retorno){
                   $("#btn_login").text("Entrar");
                   $("#btn_login").attr("disabled", false);
                   if(retorno.success == true){
                       toastr.success('Seja Bem Vindo(a), o seu acesso foi permitido e você poderá utilizar normalmente.');
                       setTimeout(function(){
                           window.location.href = "painel/";
                       }, 3000);
                   } else {
                       toastr.error(retorno['message']);
                   }
               }
           });
       });
   });
});
</script>
</body>
</html>