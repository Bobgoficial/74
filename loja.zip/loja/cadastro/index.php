<?php 
session_start(); 
?>

<html lang="pt-br">
<head><meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PladixStore | Página de Cadastro</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://acegif.com/wp-content/gifs/raining-money-42.gif"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="../vendors/bundle.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="../assets/css/app.min.css" type="text/css">
     <script src="https://www.google.com/recaptcha/api.js?render=6LdGZo8eAAAAAA3NeqRHK58-7Kmy9rSQkIM3iQ9n"></script>
</head>
<body class="form-membership dark">

<!-- begin::preloader-->
<div class="preloader">
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="50px" height="50px" viewBox="0 0 128 128"
         xml:space="preserve">
        <rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>
        <g>
            <path d="M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z"
                  fill="#000000" fill-opacity="1"/>
            <animateTransform attributeName="transform" type="rotate" from="0 64 64" to="360 64 64"
                              dur="500ms" repeatCount="indefinite">
            </animateTransform>
        </g>
    </svg>
</div>
<!-- end::preloader -->

    <!-- logo -->
   <!--<div id="logo">
        <img class="logo" src="../assets/secxstore3.png" alt="image">
        <img class="logo-dark" style="width: 60%; height: 160%;"src="../assets/secxstore3.png" alt="image"> 
    </div>-->
    <!-- ./ logo -->
    
    <div class="form-wrapper">
    <h5 class="text-primary">PladixStore - Página de Cadastro</h5>
    <!-- form -->
    <form>
        <div class="form-group">
            <input type="text" id="usuario" class="form-control" placeholder="Digite seu usuário:" required autofocus>
        </div>
        <div class="form-group">
            <input type="password" id="senha" class="form-control" placeholder="Digite uma senha:" required>
        </div>
        <div class="form-group">
            <input type="password" id="senhanovamente" class="form-control" placeholder="Confirme a senha:" required>
        </div>
        <div class="form-group">
            <input type="number" id="idtelegram" class="form-control" placeholder="ID do seu Telegram:" required>
        </div>
        <div class="form-group">
            <input type="hidden" id="coderef" class="form-control" placeholder="Código de Referência:" value="Pladix">
        </div>
        <button id="btn_cadastrar" class="btn btn-primary btn-block">Cadastrar-se</button>
        <hr>
        <p class="text-muted">Você já é cadastrado? Clique abaixo!</p>
        <a href="../" class="btn btn-outline-light btn-sm">Clique aqui!</a>
    </form>
<br>
</div>
<!-- Plugin scripts -->
<script src="../vendors/bundle.js"></script>
<script src="css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">

$("#btn_cadastrar").click(function(){
   $(this).text("Processando...");
   $(this).attr("disabled", true);

var usuario = document.getElementById("usuario").value;
var senha = document.getElementById("senha").value;
var senhanovamente = document.getElementById("senhanovamente").value;
var idtelegram = document.getElementById("idtelegram").value;

grecaptcha.ready(function(){
grecaptcha.execute("6LdGZo8eAAAAAA3NeqRHK58-7Kmy9rSQkIM3iQ9n", {action: 'homepage'}).then(function(response){
 $.ajax({
  url: "../auth/cadastro.php",
  type: "POST",
  data: {
    "usuario": usuario,
    "senha": senha,
    "senhanovamente": senhanovamente,
    "idtelegram": idtelegram,
    "g-recaptcha-response": response
  },
  dataType: "json",
  success: function(retorno){
  if(retorno.success == true){
    toastr.success("O seu cadastro foi ativado com sucesso, por favor faça login para continuar.");
    setTimeout(function(){
  window.location.href = "../";
    }, 3000);
    
  }else{
    toastr.error(retorno['message']);
          }
        }
      }); //ajax
     $("#btn_cadastrar").text("Cadastrar-se");
    $("#btn_cadastrar").attr("disabled", false);
   });
 });
  
});

</script>

<!-- App scripts -->
<script src="../assets/js/app.min.js"></script>
</body>
</html>