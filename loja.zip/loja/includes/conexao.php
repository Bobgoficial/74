<?php
error_reporting(0);
$db_host = ('localhost');
$db_user = ('u769608658_Venix');
$db_pass = ('>0+WWbu51So');
$db_name = ('u769608658_Venix');
$conexao = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die ('banco de dados invalido, tente novamente.');