<?php

session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

?>

<html lang="pt-br">
<head><meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PladixStore | Painel do Administrador</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="https://rankedbyvotes.com/wp-content/uploads/Community-Education.gif"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="vendors/bundle.css" type="text/css">

    <link rel="stylesheet" href="vendors/dataTable/dataTables.min.css" type="text/css">

    <!-- Datepicker -->
    <link rel="stylesheet" href="vendors/datepicker/daterangepicker.css">

    <!-- Slick -->
    <link rel="stylesheet" href="vendors/slick/slick.css">
    <link rel="stylesheet" href="vendors/slick/slick-theme.css">

    <!-- Vmap -->
    <link rel="stylesheet" href="vendors/vmap/jqvmap.min.css">

    <!-- App styles -->
    <link rel="stylesheet" href="assets/css/app.min.css" type="text/css">
    <script src="https://www.google.com/recaptcha/api.js?render=6LdGZo8eAAAAAA3NeqRHK58-7Kmy9rSQkIM3iQ9n"></script>
</head>
<style type="text/css">
::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}
::-webkit-scrollbar-button {
  width: 2px;
  height: 2px;
}
::-webkit-scrollbar-thumb {
  background: #8f0000;
  border: 0px none #ffffff;
  border-radius: 50px;
}
::-webkit-scrollbar-thumb:hover {
  background: #9e0000;
}
::-webkit-scrollbar-thumb:active {
  background: #000000;
}
::-webkit-scrollbar-track {
  background: #ff0000;
  border: 0px none #ffffff;
  border-radius: 50px;
}
::-webkit-scrollbar-track:hover {
  background: #ff0000;
}
::-webkit-scrollbar-track:active {
  background: #ff0000;
}
::-webkit-scrollbar-corner {
  background: transparent;
}
</style>
<body class="dark">

<!-- begin::preloader-->
<div class="preloader">
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="50px" height="50px" viewBox="0 0 128 128"
         xml:space="preserve">
        <rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>
        <g>
            <path d="M75.4 126.63a11.43 11.43 0 0 1-2.1-22.65 40.9 40.9 0 0 0 30.5-30.6 11.4 11.4 0 1 1 22.27 4.87h.02a63.77 63.77 0 0 1-47.8 48.05v-.02a11.38 11.38 0 0 1-2.93.37z"
                  fill="#000000" fill-opacity="1"/>
            <animateTransform attributeName="transform" type="rotate" from="0 64 64" to="360 64 64"
                              dur="500ms" repeatCount="indefinite">
            </animateTransform>
        </g>
    </svg>
</div>
<!-- end::preloader -->

<!-- begin::navigation -->
<div class="navigation">

    <!-- begin::logo -->
    <div id="logo">
        <a href="index.php">
        </a>
    </div>
    <!-- end::logo -->

    <!-- begin::navigation header -->
    <header class="navigation-header">
        <figure class="avatar avatar-state-success">
            <img src="https://rankedbyvotes.com/wp-content/uploads/Community-Education.gif" class="rounded-circle" alt="image">
        </figure>
        <div>
            <h5><?php echo $_SESSION['usuario']; ?></h5>
            <p class="text-muted"><?php if($_SESSION['nivel'] == 1){ echo "Cadastrado como: Administrador"; } else{ echo "Cadastrado como: Cliente";} ?></p>
            <ul class="nav">
                 <li class="nav-item">
                    <a href="https://t.me/pladixoficial" class="btn nav-link bg-primary-bright" title="Suporte" data-toggle="tooltip">
                        <i data-feather="send"></i>
                    </a>
                </li>
                <!--<li class="nav-item">
                    <a onclick="construcao();" href="#" class="btn nav-link bg-info-bright" title="Perfil" data-toggle="tooltip">
                        <i data-feather="user"></i>
                    </a>
                </li>-->
                <li class="nav-item">
                    <a href="admin.php" class="btn nav-link bg-success-bright" title="Administração" data-toggle="tooltip">
                        <i data-feather="user-plus"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../?logout=true" class="btn nav-link bg-danger-bright" title="Sair" data-toggle="tooltip">
                        <i data-feather="log-out"></i>
                    </a>
                </li>
            </ul>
        </div>
    </header>
    <!-- end::navigation header -->

    <!-- begin::navigation menu -->
    <div class="navigation-menu-body">
        <ul>
            <li class="navigation-divider">Navegação:</li>
            <li class="open">
             <li>
                <a href="index.php">
                    <i class="nav-link-icon" data-feather="bar-chart-2"></i>
                    <span>Painel de Controle</span>
                    <span class="badge badge-success">2</span>
                </a>
            </li>
            <li>
                <a href="gerenciaccs.php">
                    <i class="nav-link-icon" data-feather="credit-card"></i>
                    <span>Gerenciar Estoque</span>
                    <span class="badge badge-success">2</span>
                </a>
            </li>


                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- end::navigation menu -->

</div>
<!-- end::navigation -->

<!-- begin::main -->
<div id="main">

    <!-- begin::header -->
    <div class="header">

        <!-- begin::header left -->
        <ul class="navbar-nav">

            <!-- begin::navigation-toggler -->
            <li class="nav-item navigation-toggler">
                <a href="#" class="nav-link">
                    <i data-feather="menu"></i>
                </a>
            </li>
            <!-- end::navigation-toggler -->

            <!-- begin::header-logo -->
            <li class="nav-item" id="header-logo">
                </a>
            </li>
            <!-- end::header-logo -->
        </ul>
        <!-- end::header left -->

        <!-- begin::header-right -->
        <div class="header-right">
            <ul class="navbar-nav">

                <!-- begin::search-form -->
                <li class="nav-item search-form">
                    <div class="row">
                        <div class="col-md-6">
                            <form>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <div class="input-group-append">
                                        <button class="btn btn-default" type="button">
                                            <i data-feather="search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </li>
            <!-- begin::mobile header toggler -->
            <ul class="navbar-nav d-flex align-items-center">
                <li class="nav-item header-toggler">
                    <a href="#" class="nav-link">
                        <i data-feather="arrow-down"></i>
                    </a>
                </li>
            </ul>
            <!-- end::mobile header toggler -->
        </div>
        <!-- end::header-right -->
    </div>
    <script type="text/javascript">
    function construcao(){
    toastr.warning("Estamos fazendo alguns ajustes, tente novamente mais tarde.")
    }
    </script>
    <!-- end::header -->