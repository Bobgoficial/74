<?php

session_start();

include_once("../../../includes/conexao.php");

if($_SESSION["plano"] !== "Administrador" AND $_SESSION["plano"] !== "PLANO VIP"){
echo "Você não é usuário VIP para utilizar este checker.";
exit();
}

function contar_lives($conexao){
$usuario = $_SESSION["usuario"];
$total = $_SESSION["aprovados"] +1;
return mysqli_query($conexao, "UPDATE usuario SET aprovados='$total' WHERE usuario='$usuario'");
}


?>