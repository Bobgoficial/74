<?php
session_start();
error_reporting(0);
require_once("../includes/conexao.php");
header("content-type: application/json");

if(empty($_POST['usuario']) or empty($_POST['senha']) or empty($_POST['idtelegram'])) {
$json = ["success" => false, "message" => "As informações não foram enviadas corretamente."];
die(json_encode($json));
}

$data = array (
"secret" => "6LdqoBEqAAAAAJnZdF_J4GJH2aqxIrCdh1L8Lj4e",
"response" => $_POST["g-recaptcha-response"],
"remoteip" => $_SERVER["REMOTE_ADDR"]
);


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$api = json_decode(curl_exec($curl), true);

if($api["success"] == false){
$json = ["success" => false, "message" => "Não foi possivel realizar seu login, pois está com captcha inválido."];
echo json_encode($json);
exit();
}

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
$idtelegram = mysqli_real_escape_string($conexao, $_POST['idtelegram']);

$query = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND senha = md5('$senha')";

$result = mysqli_query($conexao, $query);

if(mysqli_num_rows($result) > 0) {

$auth_token = md5(uniqid());

$array = mysqli_fetch_assoc($result);

$chave = $array["chave"];

mysqli_query($conexao, "UPDATE usuarios SET auth_token = '$auth_token' WHERE chave = '$chave'");

session_start();
$_SESSION["logado"] = true;
$_SESSION["auth_token"] = $auth_token;
$_SESSION["saldo"] = $array["saldo"];
$_SESSION["lives"] = $array["lives"];
$_SESSION["nivel"] = $array["nivel"];
$_SESSION["chave"] = $array["chave"];
$_SESSION["usuario"] = $array["usuario"];
$pegar_ip = $_SERVER["REMOTE_ADDR"];
$host = $_SERVER['SERVER_NAME'];
$saldo = $_SESSION["saldo"] = $array["saldo"];
$nivel = $_SESSION["nivel"] = $array["nivel"];
mysqli_close($conexao);

$json = ["success" => true, "message" => "Parabéns! Você logou com sucesso."];
/*$txt = "⚙️ | *Rocket - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informações do seu cadastro:*
- Usuário: *$usuario*
- Saldo: *$saldo*
- ID do Telegram: *$idtelegram*
- Ação: *Acabou de entrar na loja virtual.*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "7273252411:AAHkWb4TcvWkcL3zWSZejAHoSya3cZ-BKEQ";
$data = ['text' => "$txt",'chat_id' => "$idtelegram", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));*/
die(json_encode($json));

}else{

$json = ["success" => false, "message" => "Usuário e senha estão incorretos, tente novamente."];
die(json_encode($json));

}


?>