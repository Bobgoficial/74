<?php
session_start();

date_default_timezone_set('America/Sao_Paulo');

require_once("../includes/conexao.php");
$token = md5(uniqid());

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
$senhanovamente = mysqli_real_escape_string($conexao, $_POST['senhanovamente']);
$idtelegram = mysqli_real_escape_string($conexao, $_POST['idtelegram']);

if(empty($usuario) or empty($senha) or empty($senhanovamente) or empty($idtelegram)){
$json = ["success" => false, "message" => "Os campos não foram preenchidos corretamente."];
die(json_encode($json));
}

$data = array (
"secret" => "6LdqoBEqAAAAAJnZdF_J4GJH2aqxIrCdh1L8Lj4e",
"response" => $_POST["g-recaptcha-response"],
"remoteip" => $_SERVER["REMOTE_ADDR"]
);


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$api = json_decode(curl_exec($curl), true);

if($api["success"] == false){
$json = ["success" => false, "message" => "Você não preencheu o Recaptcha corretamente."];
echo json_encode($json);
exit();
}

if($senhanovamente !== $senha){
$json = array("success" => false, "message" => "O cadastro não foi feito pois as senhas estão erradas.");
die(json_encode($json));
}

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$result = mysqli_query($conexao, $sql);

if(mysqli_num_rows($result) >= 1) {
$json = array("success" => false, "message" => "O usuário escolhido já existe.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$cad = mysqli_query($conexao, "INSERT INTO usuarios (usuario, senha, saldo, chave, nivel, idtelegram)
VALUES ('$usuario', md5('$senha'), '0', '$token', '0', '$idtelegram');");
if(mysqli_affected_rows($conexao) > 0) {
/*$txt = "⚙️ | *Rocket - Alertas*
- *Esta mensagem é apenas os logs que você receberá de forma exclusiva.*

ℹ️ | *Informações do seu cadastro:*
- Usuário: *$usuario*
- ID do Telegram: *$idtelegram*
- Ação: *Acabou de se cadastrar na loja virtual.*

ℹ️ | *Caso não tenha nosso site, confira abaixo:*
- *✅ | https://pladix.live/store/ - Boas compras! :D*

⚙️ | *Sistema de Logs by: @pladixoficial*";
$botoken = "7273252411:AAHkWb4TcvWkcL3zWSZejAHoSya3cZ-BKEQ";
$data = ['text' => "$txt",'chat_id' => "-1001768892332", 'parse_mode' => 'Markdown'];
file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));*/
$json = ["success" => true, "message" => "Parabéns! O seu cadastro foi feito com sucesso."];
echo json_encode($json);
mysqli_close($conexao);
exit();
 }

else{
$json = array("success" => false, "message" => "Falha ao se cadastrar na store.");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>